using System.Drawing;
using RadioRecorder.Core;

namespace RadioRecorder.UI;

public sealed class ScheduleForm : Form
{
    private readonly DataGridView grid = new() { Dock = DockStyle.Fill, RowHeadersVisible = false, AllowUserToAddRows = false,
        AllowUserToDeleteRows = false, AllowUserToResizeRows = false, ReadOnly = true, MultiSelect = false, SelectionMode = DataGridViewSelectionMode.CellSelect };
    private readonly bool[][] values;
    public ScheduleForm(Settings settings)
    {
        values = settings.Schedule.Select(r => r.ToArray()).ToArray();
        Text = "Планировщик — RadioRecorder";
        ClientSize = new Size(685, 670);
        Font = new Font("Segoe UI", 9f);
        StartPosition = FormStartPosition.CenterParent;
        ShowIcon = true;
        Icon = AppIcon.Load();
        grid.Columns.Add("time", "Часы");
        grid.Columns[0].Width = 116;
        string[] days = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];
        foreach (string day in days) { int i = grid.Columns.Add(day, day); grid.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill; grid.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable; }
        for (int h = 0; h < 24; h++)
        {
            int row = grid.Rows.Add($"{h:00}:00 - {(h + 1) % 24:00}:00", "", "", "", "", "", "", "");
            grid.Rows[row].Height = 23;
            for (int d = 0; d < 7; d++) Paint(h, d);
        }
        grid.CellClick += (_, e) => { if (e.ColumnIndex <= 0 || e.RowIndex < 0) return; int day = e.ColumnIndex - 1; values[day][e.RowIndex] = !values[day][e.RowIndex]; Paint(e.RowIndex, day); grid.ClearSelection(); };
        var footer = new FlowLayoutPanel { Dock = DockStyle.Bottom, FlowDirection = FlowDirection.RightToLeft, Height = 44 };
        var ok = new Button { Text = "Сохранить", AutoSize = true };
        ok.Click += (_, _) => { settings.Schedule = values; settings.Save(); DialogResult = DialogResult.OK; Close(); };
        var cancel = new Button { Text = "Отмена", AutoSize = true, DialogResult = DialogResult.Cancel };
        footer.Controls.Add(ok); footer.Controls.Add(cancel);
        var hint = new Label { Text = "Зелёный час — запись разрешена. Щёлкни по ячейке, чтобы переключить.", Dock = DockStyle.Top, Height = 36, Padding = new Padding(8) };
        Controls.Add(grid); Controls.Add(hint); Controls.Add(footer);
    }
    private void Paint(int hour, int day)
    {
        var cell = grid.Rows[hour].Cells[day + 1];
        cell.Style.BackColor = values[day][hour] ? Color.FromArgb(164, 246, 153) : Color.White;
        cell.Style.SelectionBackColor = cell.Style.BackColor;
    }
}
