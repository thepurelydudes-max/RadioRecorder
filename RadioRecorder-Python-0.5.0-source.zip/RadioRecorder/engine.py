"""RadioRecorder: Windows DirectShow or PortAudio -> FFmpeg continuous MP3 segment muxer.

All worker callbacks are invoked from background threads. Tk callbacks must be
marshalled to the UI thread with a queue.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timedelta
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import threading
import time
from typing import Callable
from cues import TrackEvent, make_cue, write_cue_atomic
from audio_levels import peak_dbfs

APP_DIR = Path(__file__).resolve().parent
if getattr(__import__('sys'), 'frozen', False):
    APP_DIR = Path(__import__('sys').executable).resolve().parent
SETTINGS_FILE = APP_DIR / "settings.json"
RETENTION_STATE_FILE = APP_DIR / "retention_state.json"


DEFAULTS = {
    "source": "", "source_kind": "device", "stream_url": "http://192.168.2.170:8000/",
    "sample_rate": 48000, "bitrate": 128, "channels": 1,
    "folder": str(Path.home() / "Music" / "RadioRecorder"),
    "filename_format": "%d-%m-%y_%hh-%mm",
    "split_enabled": True, "split_minutes": 60,
    "metadata_mode": "api", "metadata_api_url": "http://127.0.0.1:9001",
    "metadata_username": "", "metadata_password": "", "metadata_icy_url": "http://192.168.2.170:8000/",
    "cue_shift_sec": 0.0,
    "schedule": [[True for _ in range(24)] for _ in range(7)],
    "auto_schedule": False, "start_with_windows": False, "start_with_admin": False, "minimize_on_start": False,
    "ask_on_exit": True, "reboot_on_error": True,
    "keep_awake": False, "retention_enabled": True, "retention_days": 365,
    "silence_enabled": False, "silence_seconds": 10, "silence_db": -60,
    "silence_email_only_recording": True, "email_to": "",
    "smtp_server": "", "smtp_port": 587, "smtp_user": "", "smtp_password": "", "smtp_tls": True,
    "instance_name": "", "monitor_device": "Default", "monitor_input": "Auto", "source_label": "",
}


def load_config() -> dict:
    cfg = json.loads(json.dumps(DEFAULTS))
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding='utf-8'))
        if isinstance(data, dict):
            cfg.update({key: value for key, value in data.items() if key in DEFAULTS})
    except (OSError, ValueError):
        pass
    if len(cfg.get('schedule', [])) != 7 or any(len(row) != 24 for row in cfg['schedule']):
        cfg['schedule'] = json.loads(json.dumps(DEFAULTS['schedule']))
    return cfg


def save_config(config: dict) -> None:
    SETTINGS_FILE.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding='utf-8')


def ffmpeg_path() -> str:
    local = APP_DIR / "ffmpeg.exe"
    if local.is_file():
        return str(local)
    return shutil.which("ffmpeg") or ""


def format_to_strftime(pattern: str) -> str:
    """Convert RadioLogger %y%m%d-%hh%mm%ss syntax to FFmpeg strftime."""
    if not pattern.strip():
        raise ValueError("Укажи формат имени файла")
    tokens = {"%hh": "%H", "%mm": "%M", "%ss": "%S",
              "%y": "%Y", "%m": "%m", "%d": "%d"}
    token_pattern = re.compile("|".join(re.escape(t) for t in tokens))
    output = token_pattern.sub(lambda m: tokens[m.group()], pattern)
    # Unknown printf tags, path traversal and Windows-invalid names are rejected.
    if re.search(r'%(?![YmdHMS])', output) or output.endswith('%'):
        raise ValueError("Неизвестная переменная в имени файла")
    if any(ch in pattern for ch in '<>:"/\\|?*') or '..' in pattern:
        raise ValueError("Недопустимые символы в имени файла")
    if '%' not in output:
        raise ValueError("Добавь в имя дату и время, чтобы файлы не перезаписывались")
    return output


def preview_name(pattern: str, at: datetime | None = None) -> str:
    return (at or datetime.now()).strftime(format_to_strftime(pattern)) + ".mp3"


def clock_boundary(at: datetime, minutes: int = 60) -> datetime:
    """Wall-clock split boundary measured from local midnight, not start time.

    For minutes=60 an input at 12:07 belongs to the file that started at
    12:00. The first recording of a session may begin mid-hour; subsequent
    files always use the scheduled wall-clock boundary.
    """
    if not 1 <= minutes <= 1440:
        raise ValueError("Неверный интервал разделения")
    midnight = at.replace(hour=0, minute=0, second=0, microsecond=0)
    elapsed = at.hour * 60 + at.minute
    return midnight + timedelta(minutes=elapsed // minutes * minutes)


def list_audio_devices(ffmpeg: str) -> list[tuple[str, str]]:
    """(label, device selector). The alternative DirectShow name is unique."""
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        run = subprocess.run([ffmpeg, "-hide_banner", "-list_devices", "true",
                              "-f", "dshow", "-i", "dummy"],
                             capture_output=True, text=True, errors="replace",
                             timeout=8, creationflags=flags)
    except (OSError, subprocess.TimeoutExpired):
        return []
    is_audio = False
    devices: list[tuple[str, str]] = []
    for line in run.stderr.splitlines():
        if "DirectShow audio devices" in line:
            is_audio = True
            continue
        if "DirectShow video devices" in line:
            is_audio = False
            continue
        if not is_audio:
            continue
        alt = re.search(r'Alternative name "([^"]+)"', line)
        if alt and devices:
            label, _ = devices[-1]
            devices[-1] = (label, alt.group(1))
            continue
        item = re.search(r'\]\s+"([^"]+)"', line)
        if item:
            devices.append((item.group(1), item.group(1)))
    return devices


@dataclass
class Segment:
    path: Path
    started: datetime


class Recorder:
    def __init__(self, on_status: Callable[[str], None],
                 on_elapsed: Callable[[float], None] | None = None,
                 on_meter: Callable[[float], None] | None = None,
                 on_silence: Callable[[], None] | None = None):
        self.on_status = on_status
        self.on_elapsed = on_elapsed or (lambda t: None)
        self.on_meter = on_meter or (lambda db: None)
        self.on_silence = on_silence or (lambda: None)
        self.last_silence_alert = 0.0
        self.lock = threading.RLock()
        self.stop_requested = threading.Event()
        self.process: subprocess.Popen | None = None
        self.watch_thread: threading.Thread | None = None
        self.cfg: dict = {}
        self.segment: Segment | None = None
        self.segments: list[Segment] = []
        self.events: list[TrackEvent] = []
        self.last_title = "Неизвестный трек"
        self.initial_title = "Неизвестный трек"
        self.known_paths: set[Path] = set()
        self.recording_started: datetime | None = None
        self.running = False
        self.next_warning_sent = False
        self._audio_thread: threading.Thread | None = None

    def start(self, config: dict, initial_title: str = "") -> None:
        if self.running:
            return
        ffmpeg = ffmpeg_path()
        if not ffmpeg:
            raise RuntimeError("ffmpeg.exe не найден. Положи его рядом с программой")
        if not config.get("source") and config.get("source_kind") != "stream":
            raise RuntimeError("Выбери вход записи (Line In / Microphone / VAC)")
        output = Path(config["folder"]).expanduser()
        output.mkdir(parents=True, exist_ok=True)
        if not config.get('split_enabled', True) and int(config.get('split_minutes', 60)) != 60:
            self.on_status("Разделение отключено: будет один файл")
        self.cfg = config.copy()
        self.recording_started = datetime.now()
        self.known_paths = set(output.glob('*.mp3'))
        self.segment = None
        self.segments.clear()
        self.events.clear()
        self.last_title = initial_title or 'Неизвестный трек'
        self.initial_title = self.last_title
        self.stop_requested.clear()
        self.next_warning_sent = False
        self.running = True
        try:
            self._spawn()
        except Exception:
            self.running = False
            raise
        self.watch_thread = threading.Thread(target=self._watch, name="ffmpeg-watch", daemon=True)
        self.watch_thread.start()
        self.on_status("Запись запущена")

    def _build_command(self) -> list[str]:
        c = self.cfg
        cmd = [ffmpeg_path(), '-hide_banner', '-nostdin', '-loglevel', 'info', '-n']
        if c.get('source_kind') == 'stream':
            cmd.extend(['-i', c['stream_url']])
        elif str(c.get('source', '')).startswith('portaudio:'):
            # PortAudio captures the exact input listed by Windows, feeding raw
            # PCM to FFmpeg's *existing* hourly segmenter. No network audio.
            cmd.extend(['-f', 's16le', '-ar', str(c['sample_rate']),
                        '-ac', str(c['channels']), '-i', 'pipe:0'])
        else:
            cmd.extend(['-thread_queue_size', '1024', '-f', 'dshow',
                        '-audio_buffer_size', '250', '-i', 'audio=' + c['source']])
        cmd += ['-map', '0:a:0', '-vn', '-ac', str(c['channels']), '-ar', str(c['sample_rate'])]
        filters = ['ebur128=peak=true']
        if c.get('silence_enabled'):
            filters.insert(0, 'silencedetect=noise=' + str(int(c['silence_db'])) +
                           'dB:d=' + str(int(c['silence_seconds'])))
        cmd += ['-af', ','.join(filters), '-codec:a', 'libmp3lame',
                '-b:a', str(c['bitrate']) + 'k']
        fmt = format_to_strftime(c['filename_format'])
        # Avoid overwriting old recordings, including when app is restarted.
        # Ensure that manual restarts in the same hour cannot overwrite earlier audio.
        suffix_index = 1
        while True:
            suffix = '' if suffix_index == 1 else f'_part{suffix_index}'
            pat = (fmt + suffix) + '.mp3'
            candidate = Path(c['folder']) / datetime.now().strftime(pat)
            if not candidate.exists() and candidate not in self.known_paths:
                break
            suffix_index += 1
        if c.get('split_enabled', True):
            mins = int(c.get('split_minutes', 60))
            if not 1 <= mins <= 1440:
                raise ValueError('Неверный интервал разделения')
            cmd += ['-f', 'segment', '-segment_format', 'mp3', '-segment_time',
                    str(mins * 60), '-segment_atclocktime', '1',
                    '-reset_timestamps', '1', '-strftime', '1', str(Path(c['folder']) / pat)]
        else:
            cmd += ['-f', 'mp3', str(Path(c['folder']) / datetime.now().strftime(pat))]
        return cmd

    def _spawn(self) -> None:
        flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
        use_portaudio = (self.cfg.get('source_kind') == 'device' and
                         str(self.cfg.get('source', '')).startswith('portaudio:'))
        self.process = subprocess.Popen(self._build_command(),
                                        stdin=subprocess.PIPE if use_portaudio else subprocess.DEVNULL,
                                        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                                        text=True, errors='replace', bufsize=1,
                                        creationflags=flags)
        threading.Thread(target=self._read_stderr, args=(self.process,),
                         name="ffmpeg-log", daemon=True).start()
        if use_portaudio:
            proc = self.process
            self._audio_thread = threading.Thread(target=self._capture_portaudio,
                                                  args=(proc,), name='portaudio-capture', daemon=True)
            self._audio_thread.start()

    def _capture_portaudio(self, proc: subprocess.Popen) -> None:
        """Push only locally captured PCM to FFmpeg; HTTP remains metadata-only."""
        try:
            import sounddevice as sd
            from monitor import resolve_device
            devices, apis = sd.query_devices(), sd.query_hostapis()
            choice = self.cfg['source'].split(':', 1)[1]
            device_id = resolve_device(choice, 'input', devices, apis)
            channels = int(self.cfg['channels'])
            if channels > int(devices[device_id]['max_input_channels']):
                raise RuntimeError('Вход поддерживает меньше каналов, чем настроено')
            rate = int(self.cfg['sample_rate'])
            if proc.stdin is None:
                raise RuntimeError('Не открыт канал PCM для FFmpeg')
            with sd.RawInputStream(samplerate=rate, device=device_id,
                                   channels=channels, dtype='int16', blocksize=1024) as stream:
                last_meter = 0.0
                while not self.stop_requested.is_set() and proc.poll() is None:
                    data, overflow = stream.read(1024)
                    if time.monotonic() - last_meter >= 0.12:
                        last_meter = time.monotonic()
                        self.on_meter(peak_dbfs(data))
                    proc.stdin.buffer.write(data)
                    proc.stdin.buffer.flush()
        except (OSError, RuntimeError, ValueError, ImportError) as exc:
            if not self.stop_requested.is_set():
                self.on_status('Ошибка захвата Windows/PortAudio: ' + str(exc))
                if proc.poll() is None:
                    proc.terminate()
        finally:
            if proc.stdin:
                try:
                    proc.stdin.close()
                except (OSError, ValueError):
                    pass

    def _read_stderr(self, process: subprocess.Popen) -> None:
        if process.stderr is None:
            return
        recent_lines: list[str] = []
        for line in process.stderr:
            line = line.strip()
            if not line:
                continue
            recent_lines.append(line)
            if len(recent_lines) > 8:
                recent_lines.pop(0)
            # EBU loudness is approximate indication, not a calibrated dBFS VU.
            meter = re.search(r'FTPK:\s*(-?\d+(?:\.\d+)?)', line)
            if meter:
                try:
                    self.on_meter(float(meter.group(1)))
                except ValueError:
                    pass
            if 'silence_start:' in line:
                self.on_status('Обнаружена тишина: ' + line.split('silence_start:')[-1].strip())
                if time.monotonic() - self.last_silence_alert >= 60:
                    self.last_silence_alert = time.monotonic()
                    self.on_silence()
            if any(s in line.lower() for s in ('error opening input', 'error opening output',
                                                 'could not find', 'invalid argument',
                                                 'cannot open', 'no such device',
                                                 'permission denied', 'device busy')):
                self.on_status('FFmpeg: ' + line[-220:])
        if process.poll() and not self.stop_requested.is_set():
            self.on_status('FFmpeg завершился: ' + ' | '.join(recent_lines[-3:])[-380:])

    def _watch(self) -> None:
        last_bytes = -1
        last_growth = time.monotonic()
        while not self.stop_requested.is_set():
            proc = self.process
            if proc is not None and proc.poll() is not None:
                if self.cfg.get('reboot_on_error'):
                    self.on_status('Ошибка записи; повторное подключение через 5 секунд')
                    if self.stop_requested.wait(5):
                        break
                    try:
                        self._spawn()
                        self.on_status('Рекордер перезапущен')
                    except OSError as exc:
                        self.on_status('Ошибка перезапуска: ' + str(exc))
                    continue
                self.on_status('Запись остановлена из-за ошибки FFmpeg')
                break
            self._discover_segments()
            # Detect a stalled encoder without mistaking actual radio silence for
            # stalled audio: MP3 files continue growing when recording silence.
            try:
                current_file = self.segment.path if self.segment else None
                size = current_file.stat().st_size if current_file else 0
            except OSError:
                size = 0
            if size != last_bytes:
                last_bytes = size
                last_growth = time.monotonic()
            elif time.monotonic() - last_growth > 35:
                self.on_status('Нет новых аудиоданных 35 сек: перезапуск кодировщика')
                if proc is not None and proc.poll() is None:
                    proc.terminate()
                last_growth = time.monotonic()
            if self.recording_started:
                self.on_elapsed((datetime.now() - self.recording_started).total_seconds())
            # Once per local calendar day after 00:00, even if recording
            # starts later in the day. State survives application restarts.
            self.cleanup_if_due()
            self.stop_requested.wait(0.25)
        self._discover_segments()
        with self.lock:
            self._update_all_cues()
        self.running = False

    def _discover_segments(self) -> None:
        folder = Path(self.cfg['folder'])
        with self.lock:
            new_paths = set(folder.glob('*.mp3')) - self.known_paths
            # Sort by birth/modified time to process all files if app was busy.
            for path in sorted(new_paths, key=lambda p: (p.stat().st_mtime, p.name)):
                try:
                    if path.stat().st_size < 1:
                        continue
                except OSError:
                    continue
                self.known_paths.add(path)
                now = datetime.now()
                if self.segment is None:
                    start = self.recording_started or now
                else:
                    # A segment starts at the LOCAL CLOCK boundary (12:00,
                    # 13:00...), never "60 minutes since start" (11:23 ->
                    # 12:23). This stays correct if discovery happens late.
                    mins = int(self.cfg.get('split_minutes', 60))
                    start = clock_boundary(now, mins)
                    if self.segment.started >= start:
                        # Can happen after manual restarts or unusual clock
                        # corrections. Preserve strictly ascending windows.
                        start = self.segment.started + timedelta(milliseconds=10)
                self.segment = Segment(path, start)
                self.segments.append(self.segment)
                # Long-running radio stations can create thousands of hourly
                # files. Previous CUE sheets are already finalized; retain
                # only a few recent segments in memory for delayed API events.
                if len(self.segments) > 4:
                    self.segments = self.segments[-4:]
                    cutoff = self.segments[0].started
                    older = [e for e in self.events if e.at < cutoff]
                    carry = older[-1:]  # title at the beginning of the oldest segment
                    self.events = carry + [e for e in self.events if e.at >= cutoff]
                    if carry:
                        self.initial_title = carry[-1].title
                self.on_status('Новый файл: ' + path.name)
                self._update_all_cues()

    def add_event(self, event: TrackEvent) -> None:
        with self.lock:
            try:
                sec = float(self.cfg.get('cue_shift_sec', 0))
            except (ValueError, TypeError):
                sec = 0
            shifted = TrackEvent(event.at + timedelta(seconds=sec), event.title, event.source)
            if any(x.at == shifted.at and x.title == shifted.title for x in self.events):
                return
            self.events.append(shifted)
            self.events.sort(key=lambda e: e.at)
            self.last_title = self.events[-1].title
            self._update_all_cues()

    def _update_all_cues(self) -> None:
        for i, s in enumerate(self.segments):
            if i + 1 < len(self.segments):
                end = self.segments[i + 1].started
            else:
                end = datetime.now() + timedelta(days=1)
            # Initial title is the last known title from before the recording.
            text = make_cue(s.path.name, s.started, end,
                            self.events, initial_title=self.initial_title)
            try:
                write_cue_atomic(s.path.with_suffix('.cue'), text)
            except OSError as exc:
                self.on_status('Ошибка CUE: ' + str(exc))

    def stop(self) -> None:
        self.stop_requested.set()
        proc = self.process
        if proc is not None and proc.poll() is None:
            # SIGTERM Windows equivalent; end recording promptly.
            proc.terminate()
            try:
                proc.wait(timeout=4)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=2)
        if self.watch_thread and self.watch_thread is not threading.current_thread():
            self.watch_thread.join(timeout=3)
        self.process = None
        self.running = False
        with self.lock:
            self._update_all_cues()
        self.on_status('Запись остановлена')

    def cleanup_if_due(self, now: datetime | None = None) -> bool:
        """Do cleanup at most once per local calendar day while recording.

        The daily check runs when recording starts (if not yet done today),
        and again after each subsequent midnight while recording remains on.
        An atomic state file prevents another cleanup after an app restart.
        """
        if not self.running or not self.cfg.get('retention_enabled', False):
            return False
        now = now or datetime.now()
        folder = Path(self.cfg['folder']).expanduser().resolve()
        key = str(folder).casefold() if os.name == 'nt' else str(folder)
        with self.lock:
            desired_state = {'folder': key, 'date': now.date().isoformat()}
            if getattr(self, '_retention_last_in_memory', None) == desired_state:
                return False
            if time.monotonic() < getattr(self, '_retention_retry_after', 0.0):
                return False
            try:
                state = json.loads(RETENTION_STATE_FILE.read_text(encoding='utf-8'))
            except (OSError, ValueError):
                state = {}
            if not isinstance(state, dict):
                state = {}
            if state.get('folder') == key and state.get('date') == now.date().isoformat():
                self._retention_last_in_memory = desired_state
                return False
            try:
                deleted = self.cleanup_old(now)
            except (OSError, ValueError) as exc:
                self._retention_retry_after = time.monotonic() + 300  # avoid repeating errors
                self.on_status('Автоочистка не завершена: ' + str(exc))
                return False
            # Persist only when deletion scanning completed; log any I/O
            # error, but suppress repeated scans in this process.
            state = desired_state
            self._retention_last_in_memory = state
            try:
                tmp = RETENTION_STATE_FILE.with_name(RETENTION_STATE_FILE.name + '.tmp')
                tmp.write_text(json.dumps(state, ensure_ascii=False), encoding='utf-8')
                os.replace(tmp, RETENTION_STATE_FILE)
            except OSError as exc:
                self.on_status('Не удалось сохранить дату автоочистки: ' + str(exc))
            self.on_status(f'Ежедневная автоочистка: удалено файлов: {deleted}')
            return True

    def cleanup_old(self, now: datetime | None = None) -> int:
        """Delete ALL expired immediate files in the recordings directory.

        Retention uses whole calendar days: before midnight (today - N days).
        Never recurse, follow symlinks, or delete an open audio/CUE file.
        Call directly for tests; normal operation goes via cleanup_if_due().
        """
        if not self.cfg.get('retention_enabled', False):
            return 0
        now = now or datetime.now()
        days = int(self.cfg.get('retention_days', 365))
        if not 1 <= days <= 3650:
            raise ValueError('Срок хранения должен быть от 1 до 3650 дней')
        folder = Path(self.cfg.get('folder', '')).expanduser().resolve()
        if (not folder.is_dir() or folder == folder.parent or
            folder == Path.home().resolve() or
            folder == APP_DIR.resolve() or folder in APP_DIR.resolve().parents):
            raise ValueError('Нужна отдельная папка архива; нельзя очищать папку программы, домашнюю или корень диска')
        deadline = (now.replace(hour=0, minute=0, second=0, microsecond=0)
                    - timedelta(days=days)).timestamp()
        count = 0
        with self.lock:
            # Recent segments still have their CUE rewritten when metadata
            # arrives. Keep both files safe during cleanup.
            active = {s.path.resolve() for s in self.segments}
            active.update(p.with_suffix('.cue') for p in tuple(active))
            for file in folder.iterdir():
                if file.is_symlink() or not file.is_file() or file.resolve() in active:
                    continue
                try:
                    if file.stat().st_mtime < deadline:
                        file.unlink()
                        count += 1
                        self.on_status('Удалён старый файл: ' + file.name)
                except OSError as exc:
                    self.on_status('Автоудаление ' + file.name + ': ' + str(exc))
        return count


def next_clock_hour(now: datetime) -> datetime:
    """Next hour strictly AFTER manual Stop; roll 23:xx across midnight."""
    return now.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)


def auto_should_start(cfg: dict, now: datetime,
                      manual_pause_until: datetime | None = None) -> bool:
    """Auto stays enabled after Stop, but cannot restart in the same hour.

    Once the pause expires, normal weekly scheduler rules apply; if the next
    hour is disabled, keep waiting for the next enabled scheduled hour.
    """
    return (bool(cfg.get('auto_schedule', False))
            and (manual_pause_until is None or now >= manual_pause_until)
            and is_schedule_active(cfg, now))


def is_schedule_active(cfg: dict, at: datetime | None = None) -> bool:
    at = at or datetime.now()
    return bool(cfg.get('schedule', DEFAULTS['schedule'])[at.weekday()][at.hour])
