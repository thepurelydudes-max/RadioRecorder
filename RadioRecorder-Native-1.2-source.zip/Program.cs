using System.Globalization;
using System.Windows.Forms;

namespace RadioRecorder;

internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        if (args.Length > 0 && args[0].StartsWith("--", StringComparison.Ordinal))
        {
            Environment.ExitCode = Core.WindowsAutostart.HandleElevatedCommand(args);
            return;
        }
        Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.ThreadException += (_, e) => MessageBox.Show(e.Exception.ToString(), "RadioRecorder — ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        Application.Run(new UI.MainForm());
    }
}
