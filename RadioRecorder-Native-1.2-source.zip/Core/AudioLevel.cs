using NAudio.Wave;

namespace RadioRecorder.Core;

/// <summary>Peak dBFS calculated from the actual capture/decoded PCM bytes.</summary>
public static class AudioLevel
{
    public static double PeakDb(byte[] pcm, int count, WaveFormat format)
    {
        if (count <= 0) return -60;
        double peak = 0;
        var span = pcm.AsSpan(0, Math.Min(count, pcm.Length));
        if (format.Encoding == WaveFormatEncoding.IeeeFloat && format.BitsPerSample == 32)
        {
            for (int p = 0; p + 4 <= span.Length; p += 4)
            {
                float value = BitConverter.ToSingle(span.Slice(p, 4));
                if (float.IsFinite(value)) peak = Math.Max(peak, Math.Abs(value));
            }
        }
        else if (format.Encoding == WaveFormatEncoding.Pcm)
        {
            switch (format.BitsPerSample)
            {
                case 16:
                    for (int p = 0; p + 2 <= span.Length; p += 2)
                        peak = Math.Max(peak, Math.Abs(System.Buffers.Binary.BinaryPrimitives.ReadInt16LittleEndian(span.Slice(p, 2)) / 32768d));
                    break;
                case 24:
                    for (int p = 0; p + 3 <= span.Length; p += 3)
                    {
                        int sample = (span[p] | (span[p + 1] << 8) | (span[p + 2] << 16));
                        sample = (sample << 8) >> 8; // sign extension
                        peak = Math.Max(peak, Math.Abs(sample / 8388608d));
                    }
                    break;
                case 32:
                    for (int p = 0; p + 4 <= span.Length; p += 4)
                        peak = Math.Max(peak, Math.Abs(System.Buffers.Binary.BinaryPrimitives.ReadInt32LittleEndian(span.Slice(p, 4)) / 2147483648d));
                    break;
                case 8:
                    foreach (byte sample in span)
                        peak = Math.Max(peak, Math.Abs((sample - 128) / 128d));
                    break;
            }
        }
        return Math.Clamp(20 * Math.Log10(Math.Max(peak, 1e-6)), -60, 0);
    }

    // WASAPI typically reports WAVE_FORMAT_EXTENSIBLE. Its encoded subtype
    // controls how bytes should be interpreted; do not treat float as integer PCM.
    public static WaveFormat NormalizeFormat(WaveFormat format)
    {
        if (format is WaveFormatExtensible extensible && format.Encoding == WaveFormatEncoding.Extensible)
        {
            // KSDATAFORMAT_SUBTYPE_IEEE_FLOAT / KSDATAFORMAT_SUBTYPE_PCM
            var floating = new Guid("00000003-0000-0010-8000-00aa00389b71");
            var pcm = new Guid("00000001-0000-0010-8000-00aa00389b71");
            if (extensible.SubFormat == floating && format.BitsPerSample == 32)
                return WaveFormat.CreateIeeeFloatWaveFormat(format.SampleRate, format.Channels);
            if (extensible.SubFormat == pcm)
                return new WaveFormat(format.SampleRate, format.BitsPerSample, format.Channels);
        }
        return format;
    }

    public static string FfmpegInputFormat(WaveFormat format) => (format.Encoding, format.BitsPerSample) switch
    {
        (WaveFormatEncoding.IeeeFloat, 32) => "f32le",
        (WaveFormatEncoding.Pcm, 16) => "s16le",
        (WaveFormatEncoding.Pcm, 24) => "s24le",
        (WaveFormatEncoding.Pcm, 32) => "s32le",
        (WaveFormatEncoding.Pcm, 8) => "u8",
        _ => throw new NotSupportedException($"Формат входного устройства не поддерживается: {format.Encoding}, {format.BitsPerSample} бит")
    };
}
