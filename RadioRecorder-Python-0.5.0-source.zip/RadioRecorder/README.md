<!-- The Python branch is independent from the native C# branch. -->
# RadioRecorder Python 0.5

Portable Windows MP3 radio capture with **wall-clock hourly splitting** (e.g. 12:00, 13:00, independent of when capture started) and RadioBOSS-compatible CUE sheets from **independent** metadata polling.

**Русская инструкция:** [QUICKSTART_RU.md](QUICKSTART_RU.md).

## Development

Runtime uses Python standard library, **sounddevice/PortAudio for monitoring**, and an external `ffmpeg.exe` adjacent to the executable. Development without packaging:

```powershell
py -3.12 -m pip install -r requirements.txt
py -3.12 app.py
```

Install `ffmpeg.exe` in the project directory or put `ffmpeg` on PATH. On Windows the GUI discovers DirectShow audio inputs via `ffmpeg -list_devices true -f dshow -i dummy`.

### Tests

```powershell
py -3.12 -m unittest discover -s tests -v
```

### Live monitoring (v0.3)

The main window's **▶** button toggles preview on the next press, and stays ▶ (green while on). It never records. It starts/stops preview of the selected *recording source* without starting/stopping MP3 recording. **Rec** is separate and shows a bright red round indicator while FFmpeg records; the Stop button has a 12px square (both icons share the same bounds). Output selection is in Settings → Воспроизведение (speaker/headphones). When recording from a Windows line input, the app opens its PortAudio input in shared mode and plays it through the selected output (no new FFmpeg recorder). If automatic DirectShow-to-PortAudio name matching fails, choose an explicit monitoring input there. For HTTP audio input, preview decodes the HTTP stream via FFmpeg. Monitoring may not work for devices exclusively locked by Windows/another application; it reports an error without stopping MP3 recording.

**Note:** monitoring the selected *local line input* is distinct from using the RadioBOSS ICY endpoint **for metadata only**. If you want to hear the broadcast stream itself, choose HTTP as the recording input; do not confuse it with the ICY metadata URL.

### Persistent Auto mode (v0.4.1)

Manual **Stop** ends only the current audio session, not the checked **Auto** mode. The scheduler skips automatic restarts for the remainder of the current wall-clock hour and retries at the next allowed scheduled hour. **Rec** can override this pause. The checkbox setting is persistent: reopening the program resumes automatic recording when the current hour is enabled.

The EXE/taskbar logo now loads packaged resources from PyInstaller's `_MEIPASS` when needed, while app settings and `ffmpeg.exe` stay beside the executable. This is still a bundled Python application; migrating it to native C#/Win32 requires a separate rewrite.

### Automatic daily retention (v0.3)

When MP3 recording is running, the recorder removes **any expired regular file directly inside the recordings folder** (not just MP3/CUE pairs). It runs once per local date after midnight, or upon starting recording later that day when no cleanup has run. Expiration is based on last modification time with a midnight/day cutoff: at `2026-10-27 00:00`, 7 days of retention means removing files with timestamps **before `2026-10-20 00:00`**. It does not recurse into folders, follow symlinks, or delete currently open and recently updated MP3/CUE segments. It refuses dangerous folder targets such as the app folder, home folder, and drive roots. Daily execution is persisted in `retention_state.json` next to the application. Changing the retention period while recording applies immediately; changing the recordings folder takes effect on the next recording start.

**Warning:** old unrelated files inside the selected recordings directory also get permanently deleted. Use a dedicated directory and enable retention only if that is acceptable.

### Portable EXE build on Windows

This source package includes **`build_windows.bat`** and **`build_windows.py`**. On a Windows PC with Python 3.11+ installed:

```powershell
py -m pip install -r requirements.txt pyinstaller
py build_windows.py
```

Or just double-click `build_windows.bat`. The result will be a portable folder `dist\RadioRecorder\` with `RadioRecorder.exe`, `_internal\`, and bundled assets. If `ffmpeg.exe` is placed in the project root before the build, it is copied into the built application automatically.

### Project files

| File | Role |
| --- | --- |
| `app.py` | Windows-style Russian GUI, schedule, archive, settings |
| `engine.py` | DirectShow capture, FFmpeg segmenter, recovery, CUE association |
| `metadata.py` | RadioBOSS HTTP API `getlastplayed`, `playbackinfo`, or ICY parser |
| `cues.py` | UTF-8 BOM / CRLF CUE generator with MM:SS:75fps frame indices |
| `alerts.py` | Optional SMTP warnings for recording silence |
| `monitor.py` | Independent live audio monitoring / PortAudio output selection |
| `requirements.txt` | sounddevice for input/output preview |
| `.github/workflows/windows-build.yml` | Portable ZIP build |
| `tests/test_core.py`, `tests/test_monitor.py` | CUE, filename, retention and monitor toggle tests |

### Data, privacy, operational cautions

- User settings are saved in local `settings.json` (ignored by git); the API and SMTP secrets are stored **unencrypted**. Don't publish it.
- An ICY stream client **must consume** audio bytes to reach embedded titles; those bytes are discarded, not recorded. RadioBOSS HTTP API is metadata-only.
- RadioBOSS recording and Audio Input internals are not used. RadioRecorder independently records the Windows line input. Monitoring is a separate shared-mode capture and requires an available PortAudio device.
- CUE data is a best-effort event timeline using timestamps from RadioBOSS, or times of ICY detection. Precise subsecond sync requires equipment/clock calibration and is *not* guaranteed.
- ffmpeg segment muxing can introduce small frame-boundary differences; use the generated recordings to calibrate delay.
- On unexpected power loss the currently open MP3 may be incomplete, but previously closed hourly MP3 files remain independent. Hardware/input interruptions cannot be magically repaired. The recorder retries if configured.

License for new source code has not been assigned; choose a license when creating your public repository. FFmpeg's licensing is separate (see https://ffmpeg.org/legal.html).


### Python v0.5 updates
- Retains the existing FFmpeg DirectShow path and exposes all PortAudio Windows audio inputs as an alternative PCM capture method.
- Play monitoring produces a real dBFS level meter; recording meter remains independent.
- Optional elevated login autostart via Windows Task Scheduler, with initial UAC confirmation (and UAC when disabling).
- Improved icon propagation to main, settings, schedule and archive windows.
- Audio PCM comes from Windows input; HTTP RadioBOSS supplies metadata to CUE only.
