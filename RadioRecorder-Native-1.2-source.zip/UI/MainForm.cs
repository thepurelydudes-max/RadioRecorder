using System.Drawing;
using System.Collections.Concurrent;
using System.Diagnostics;
using RadioRecorder.Core;

namespace RadioRecorder.UI;

public sealed class MainForm : Form
{
    private Settings settings = Settings.Load();
    private readonly ConcurrentQueue<string> messages = new();
    private readonly RecorderService recorder;
    private readonly MetadataService metadata;
    private readonly MonitorService monitor = new();
    private readonly System.Windows.Forms.Timer clock = new() { Interval = 1000 };
    private DateTime? pausedUntil;
    private DateTime nextAutoAttempt = DateTime.MinValue;
    private readonly Label sourceLabel = new() { AutoEllipsis = true, Height = 26, Dock = DockStyle.Top };
    private readonly Label formatLabel = new() { Height = 25, Dock = DockStyle.Top };
    private readonly Label diskLabel = new() { Height = 26, Dock = DockStyle.Top };
    private readonly Label timeLabel = new() { Text = "0:00:00", AutoSize = false, TextAlign = ContentAlignment.MiddleCenter,
        BackColor = Color.FromArgb(242, 244, 247), Font = new Font("Consolas", 13f, FontStyle.Bold), Width = 112, Height = 39 };
    private readonly Button playButton = new() { Text = "▶", Width = 47, Height = 39, Font = new Font("Segoe UI Symbol", 15f), BackColor = Color.FromArgb(241, 243, 245), FlatStyle = FlatStyle.Flat };
    private readonly Button recButton = new() { Text = "●  Rec", Width = 94, Height = 34, ForeColor = Color.Gray, Font = new Font("Segoe UI", 10f, FontStyle.Bold) };
    private readonly Button stopButton = new() { Text = "■  Stop", Width = 98, Height = 34, Font = new Font("Segoe UI", 10f, FontStyle.Bold) };
    private readonly CheckBox auto = new() { Text = "Авто", Width = 73, Height = 34 };
    private readonly RichTextBox logBox = new() { Dock = DockStyle.Fill, BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle,
        ReadOnly = true, HideSelection = false, Font = new Font("Consolas", 9f) };
    private readonly Label recordingStatus = new() { Text = "● Остановлено", AutoSize = true, ForeColor = Color.Gray };
    private readonly Label monitorStatus = new() { Text = "Прослушивание: выкл.", AutoSize = true, ForeColor = Color.Gray };
    private readonly ProgressBar meter = new() { Width = 125, Height = 16, Maximum = 100 };
    private readonly NotifyIcon tray = new();
    private bool closing;
    private DateTime lastDiskRefresh = DateTime.MinValue;

    public MainForm()
    {
        recorder = new RecorderService(s => messages.Enqueue(s));
        metadata = new MetadataService(recorder.AddTrack, s => messages.Enqueue(s));
        Text = "RadioRecorder (Native 1.2)";
        Size = new Size(780, 470);
        MinimumSize = new Size(690, 395);
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 9.5f);
        ShowIcon = true;
        Icon = AppIcon.Load();
        tray.Icon = Icon;
        tray.Text = "RadioRecorder";
        tray.Visible = false;
        tray.DoubleClick += (_, _) => { Show(); WindowState = FormWindowState.Normal; Activate(); };
        CreateLayout();
        auto.Checked = settings.AutoSchedule;
        auto.CheckedChanged += (_, _) =>
        {
            settings.AutoSchedule = auto.Checked;
            settings.Save();
            if (auto.Checked) pausedUntil = null;
            Write(auto.Checked ? "Автоматическая запись включена" : "Автоматическая запись выключена");
            SchedulerTick();
        };
        recButton.Click += (_, _) => StartRecording();
        stopButton.Click += (_, _) =>
        {
            if (auto.Checked)
            {
                pausedUntil = Settings.NextClockHour(DateTime.Now);
                Write("Stop: запись остановлена до следующего разрешённого часа " + pausedUntil.Value.ToString("HH:mm"));
            }
            StopRecording();
        };
        playButton.Click += (_, _) => TogglePreview();
        clock.Tick += (_, _) => Heartbeat();
        clock.Start();
        RefreshLabels();
        Shown += (_, _) =>
        {
            Write("RadioRecorder запущен");
            if (settings.MinimizeOnStart) BeginInvoke((Action)(() => WindowState = FormWindowState.Minimized));
            // Startup Auto: immediately record when the current hour is selected.
            BeginInvoke((Action)SchedulerTick);
        };
        Resize += (_, _) => { if (WindowState == FormWindowState.Minimized) tray.Visible = true; };
        FormClosing += OnClosing;
    }
    private static Button CreateButton(string label, EventHandler click, int width)
    {
        var btn = new Button { Text = label, Width = width, Height = 34, Margin = new Padding(0, 0, 8, 0) };
        btn.Click += click;
        return btn;
    }
    private void CreateLayout()
    {
        var menu = new MenuStrip();
        var program = new ToolStripMenuItem("RadioRecorder");
        program.DropDownItems.Add("Настройки...", null, (_, _) => OpenSettings());
        program.DropDownItems.Add("Папка записей", null, (_, _) => OpenFolder());
        program.DropDownItems.Add(new ToolStripSeparator());
        program.DropDownItems.Add("Выход", null, (_, _) => Close());
        var help = new ToolStripMenuItem("Справка");
        help.DropDownItems.Add("О программе", null, (_, _) => MessageBox.Show(this,
            "RadioRecorder 1.1 (C# / WinForms)\n\nНативный интерфейс Windows. Запись MP3 — FFmpeg.\nCUE — RadioBOSS API / ICY.\nБез Python и PyInstaller.", "О программе"));
        menu.Items.AddRange([program, help]);
        MainMenuStrip = menu;
        Controls.Add(menu);

        var body = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4,
            Padding = new Padding(10, 8, 10, 7) };
        body.RowStyles.Add(new RowStyle(SizeType.Absolute, 93));
        body.RowStyles.Add(new RowStyle(SizeType.Absolute, 45));
        body.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        body.RowStyles.Add(new RowStyle(SizeType.Absolute, 29));
        Controls.Add(body);
        body.BringToFront();
        menu.BringToFront();

        var top = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2 };
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 175));
        var descriptors = new Panel { Dock = DockStyle.Fill };
        sourceLabel.Font = new Font("Segoe UI", 9.8f, FontStyle.Bold);
        descriptors.Controls.Add(diskLabel); descriptors.Controls.Add(formatLabel); descriptors.Controls.Add(sourceLabel);
        top.Controls.Add(descriptors, 0, 0);
        var preview = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight,
            Padding = new Padding(1, 5, 0, 0), WrapContents = false };
        preview.Controls.Add(timeLabel); preview.Controls.Add(playButton);
        top.Controls.Add(preview, 1, 0);
        body.Controls.Add(top, 0, 0);

        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false, FlowDirection = FlowDirection.LeftToRight };
        buttons.Controls.Add(CreateButton("Планировщик", (_, _) => OpenSchedule(), 118));
        buttons.Controls.Add(CreateButton("Архив", (_, _) => OpenArchive(), 80));
        buttons.Controls.Add(auto);
        buttons.Controls.Add(CreateButton("Настройки", (_, _) => OpenSettings(), 94));
        // Right-to-left button arrangement: Rec next to Stop, visible at normal width.
        buttons.Controls.Add(recButton); buttons.Controls.Add(stopButton);
        body.Controls.Add(buttons, 0, 1);
        body.Controls.Add(logBox, 0, 2);
        var footer = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3 };
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34));
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40));
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 26));
        var meterBox = new FlowLayoutPanel { Dock = DockStyle.Fill };
        meterBox.Controls.Add(new Label { Text = "Уровень:", AutoSize = true }); meterBox.Controls.Add(meter);
        footer.Controls.Add(recordingStatus, 0, 0);
        footer.Controls.Add(monitorStatus, 1, 0);
        footer.Controls.Add(meterBox, 2, 0);
        body.Controls.Add(footer, 0, 3);
    }
    private void Write(string msg) => messages.Enqueue(msg);
    private void FlushLog()
    {
        int count = 0;
        while (count++ < 100 && messages.TryDequeue(out string? msg))
        {
            logBox.AppendText($"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {msg}{Environment.NewLine}");
        }
        if (logBox.Lines.Length > 1000)
        {
            logBox.Select(0, logBox.GetFirstCharIndexFromLine(200));
            logBox.SelectedText = "";
        }
    }
    private void Heartbeat()
    {
        try
        {
            recorder.Tick();
            SchedulerTick();
            bool isRecording = recorder.Running;
            recButton.ForeColor = isRecording ? Color.FromArgb(210, 28, 32) : Color.Gray;
            recordingStatus.Text = isRecording ? "● Запись идёт" : "● Остановлено";
            recordingStatus.ForeColor = isRecording ? Color.FromArgb(194, 29, 35) : Color.Gray;
            var duration = recorder.Elapsed;
            timeLabel.Text = $"{(int)duration.TotalHours}:{duration.Minutes:00}:{duration.Seconds:00}";
            // Show the real audio level when Play previews the selected Windows input,
            // even when MP3 recording is stopped. Otherwise display recording level.
            double db = monitor.Running ? monitor.LevelDb : recorder.Running ? recorder.LevelDb : -60;
            meter.Value = Math.Clamp((int)((db + 60) / 60 * 100), 0, 100);
            if (monitor.Running) monitorStatus.Text = $"Прослушивание: вкл. ({db:0} dBFS)";
            else monitorStatus.Text = "Прослушивание: выкл.";
            if ((DateTime.Now - lastDiskRefresh).TotalSeconds > 30) { RefreshLabels(); lastDiskRefresh = DateTime.Now; }
        }
        catch (Exception e) { Write("Ошибка: " + e.Message); }
        FlushLog();
    }
    private void StartRecording(bool initiatedByAuto = false)
    {
        if (recorder.Running) return;
        try
        {
            recorder.Start(settings, metadata.LastTitle);
            metadata.Start(settings);
        }
        catch (Exception ex)
        {
            if (!initiatedByAuto) MessageBox.Show(this, ex.Message, "Не удалось начать запись", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else nextAutoAttempt = DateTime.Now.AddSeconds(30);
            Write("Ошибка запуска записи: " + ex.Message);
        }
    }
    private void StopRecording()
    {
        metadata.Stop();
        recorder.Stop();
    }
    private void SchedulerTick()
    {
        if (!auto.Checked) return;
        DateTime now = DateTime.Now;
        bool wanted = settings.ShouldAutoStart(now, pausedUntil);
        if (wanted && !recorder.Running && now >= nextAutoAttempt) StartRecording(initiatedByAuto: true);
        if (!settings.IsScheduled(now) && recorder.Running) { Write("Планировщик завершил разрешённый час"); StopRecording(); }
    }
    private void TogglePreview()
    {
        try
        {
            if (monitor.Running) monitor.Stop();
            else monitor.Start(settings);
            playButton.ForeColor = monitor.Running ? Color.FromArgb(13, 130, 63) : Color.Black;
            playButton.BackColor = monitor.Running ? Color.FromArgb(210, 248, 217) : Color.FromArgb(241, 243, 245);
            monitorStatus.Text = monitor.Running ? "Прослушивание: вкл." : "Прослушивание: выкл.";
            Write(monitor.Running ? "Мониторинг включён" : "Мониторинг выключен");
        }
        catch (Exception e) { Write("Мониторинг: " + e.Message); MessageBox.Show(this, e.Message, "Прослушивание", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }
    private void RefreshLabels()
    {
        string sourceName = settings.Source;
        if (settings.SourceKind == "device" && AudioDevices.IsWindowsEndpoint(settings.Source))
        {
            try
            {
                sourceName = AudioDevices.CaptureInputs().FirstOrDefault(
                    device => device.Selector.Equals(settings.Source, StringComparison.OrdinalIgnoreCase))?.Name
                    ?? "Аудиовход отключён (выбери устройство в настройках)";
            }
            catch { sourceName = "Аудиовход Windows: ошибка получения названия"; }
        }
        sourceLabel.Text = "Источник: " + (settings.SourceKind == "device" ? sourceName : settings.StreamUrl);
        formatLabel.Text = $"Кодек: MP3 {settings.Bitrate} kbps / {settings.SampleRate} Гц / {(settings.Channels == 1 ? "моно" : "стерео")}";
        try
        {
            Directory.CreateDirectory(settings.Folder);
            var drive = new DriveInfo(Path.GetPathRoot(Path.GetFullPath(settings.Folder))!);
            double days = drive.AvailableFreeSpace / (Math.Max(32, settings.Bitrate) * 1000d / 8) / 86400;
            diskLabel.Text = $"Осталось на диске: примерно {days:N1} дней записи";
        }
        catch { diskLabel.Text = "Осталось на диске: неизвестно"; }
    }
    private void OpenSettings()
    {
        using var form = new SettingsForm(settings);
        if (form.ShowDialog(this) == DialogResult.OK)
        {
            settings = form.Value;
            Write("Настройки сохранены (для смены входа останови и запусти запись заново)");
            RefreshLabels();
        }
    }
    private void OpenSchedule()
    {
        using var form = new ScheduleForm(settings);
        if (form.ShowDialog(this) == DialogResult.OK) { Write("Расписание сохранено"); SchedulerTick(); }
    }
    private void OpenFolder()
    {
        Directory.CreateDirectory(settings.Folder);
        Process.Start(new ProcessStartInfo("explorer.exe", $"\"{settings.Folder}\"") { UseShellExecute = true });
    }
    private void OpenArchive()
    {
        using var form = new Form { Text = "Архив — RadioRecorder", Size = new Size(780, 520), StartPosition = FormStartPosition.CenterParent };
        form.ShowIcon = true; form.Icon = AppIcon.Load();
        var list = new ListView { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true };
        list.Columns.Add("Запись", 370); list.Columns.Add("Размер, МБ", 100); list.Columns.Add("CUE", 70);
        void Refresh()
        {
            list.Items.Clear();
            if (!Directory.Exists(settings.Folder)) return;
            foreach (string p in Directory.EnumerateFiles(settings.Folder, "*.mp3").OrderByDescending(p => p))
            {
                var f = new FileInfo(p);
                var row = new ListViewItem([f.Name, (f.Length / 1024d / 1024).ToString("F1"), File.Exists(Path.ChangeExtension(p, ".cue")) ? "✓" : "—"]);
                row.Tag = p; list.Items.Add(row);
            }
        }
        void OpenSelected(bool cue)
        {
            if (list.SelectedItems.Count == 0) return;
            var p = (string)list.SelectedItems[0].Tag!;
            if (cue) p = Path.ChangeExtension(p, ".cue");
            if (!File.Exists(p)) { MessageBox.Show("Файл не найден"); return; }
            Process.Start(new ProcessStartInfo(p) { UseShellExecute = true });
        }
        var row = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 50 };
        row.Controls.Add(CreateButton("Воспроизвести MP3", (_, _) => OpenSelected(false), 170));
        row.Controls.Add(CreateButton("Открыть CUE", (_, _) => OpenSelected(true), 125));
        row.Controls.Add(CreateButton("Обновить", (_, _) => Refresh(), 92));
        row.Controls.Add(CreateButton("Папка архива", (_, _) => OpenFolder(), 120));
        list.DoubleClick += (_, _) => OpenSelected(false);
        form.Controls.Add(list); form.Controls.Add(row);
        Refresh(); form.ShowDialog(this);
    }
    private void OnClosing(object? sender, FormClosingEventArgs e)
    {
        if (closing) return;
        if (settings.AskOnExit && recorder.Running &&
            MessageBox.Show(this, "Остановить запись и выйти?", "RadioRecorder", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) != DialogResult.Yes) { e.Cancel = true; return; }
        closing = true;
        clock.Stop();
        tray.Visible = false; tray.Dispose();
        metadata.Dispose();
        monitor.Dispose();
        recorder.Dispose();
    }
}
