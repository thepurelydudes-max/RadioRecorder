﻿REM DATE 2026
REM COMMENT  "Created in RadioBOSS (Stream Archive)"
FILE "25-09-2026_22-00.mp3" MP3
  TRACK 01 AUDIO
    TITLE "ВРЕМЯ - 22-00"
    INDEX 01 00:00:00
  TRACK 02 AUDIO
    TITLE "5УТРА - Белая полоса"
    INDEX 01 00:08:31
  TRACK 03 AUDIO
    TITLE "ДЖИНГЛ КОМЕТА ИИ ЛАУНЖ 10"
    INDEX 01 03:20:22
  TRACK 04 AUDIO
    TITLE "Сергей Бобунец - Реки растают"
    INDEX 01 03:33:12
  TRACK 05 AUDIO
    TITLE "ДЖИНГЛ КОМЕТА ИИ РОК 8"
    INDEX 01 06:47:13
  TRACK 06 AUDIO
    TITLE "Любэ - Главное, что есть ты у меня"
    INDEX 01 06:53:35
  TRACK 07 AUDIO
    TITLE "ROLIK ИНФОРМАЦИЯ ВЛЕТ"
    INDEX 01 10:33:13
  TRACK 08 AUDIO
    TITLE "ROLIK Росгвардия"
    INDEX 01 10:38:26
  TRACK 09 AUDIO
    TITLE "ROLIK ИНФОРМАЦИЯ ВЫЛЕТ"
    INDEX 01 11:22:52
  TRACK 10 AUDIO
    TITLE "Emin - Зови меня (совместно с Ани Лорак)"
    INDEX 01 11:26:49
  TRACK 11 AUDIO
    TITLE "ДЖИНГЛ КОМЕТА ИИ РОК 13"
    INDEX 01 14:58:52
  TRACK 12 AUDIO
    TITLE "Emin - Дай Мне Шанс"
    INDEX 01 15:04:34
  TRACK 13 AUDIO
    TITLE "ДЖИНГЛ КОМЕТА ИИ ЛАУНЖ 6"
    INDEX 01 18:22:07
  TRACK 14 AUDIO
    TITLE "Константин Арбенин - Ночи без мягких знаков"
    INDEX 01 18:33:48
  TRACK 15 AUDIO
    TITLE "ДЖИНГЛ КОМЕТА ИИ РОК 5"
    INDEX 01 22:05:01
  TRACK 16 AUDIO
    TITLE "Наталья Качура - Вороны"
    INDEX 01 22:13:53
  TRACK 17 AUDIO
    TITLE "ROLIK ВРЕДНЫЕ ПРИВЫЧКИ АЛКОГОЛЬ"
    INDEX 01 25:26:53
  TRACK 18 AUDIO
    TITLE "Лариса Долина - Двое на ветру"
    INDEX 01 25:42:23
  TRACK 19 AUDIO
    TITLE "ДЖИНГЛ КОМЕТА ИИ 3"
    INDEX 01 29:40:67
  TRACK 20 AUDIO
    TITLE "Григорий Лепс - Архангел Михаил"
    INDEX 01 29:51:60
  TRACK 21 AUDIO
    TITLE "ДЖИНГЛ КОМЕТА ИИ РОК 9"
    INDEX 01 33:42:22
  TRACK 22 AUDIO
    TITLE "Чапаев - Своих не бросаем"
    INDEX 01 33:51:43
  TRACK 23 AUDIO
    TITLE "rmxradio - novaya_volna_volgograd"
    INDEX 01 37:27:54
  TRACK 24 AUDIO
    TITLE "Город 312 - Останусь"
    INDEX 01 37:35:05
  TRACK 25 AUDIO
    TITLE "ROLIK ИНФОРМАЦИЯ ВЛЕТ"
    INDEX 01 41:05:68
  TRACK 26 AUDIO
    TITLE "ROLIK ТЕЛЕФОННЫЕ МОШЕННИКИ 2"
    INDEX 01 41:11:06
  TRACK 27 AUDIO
    TITLE "ROLIK АНАЛИЗЫ МЗ ЭФИР"
    INDEX 01 41:41:26
  TRACK 28 AUDIO
    TITLE "ИНФО Мошенники декларация денег"
    INDEX 01 42:47:11
  TRACK 29 AUDIO
    TITLE "ROLIK ИНФОРМАЦИЯ ВЫЛЕТ"
    INDEX 01 43:29:19
  TRACK 30 AUDIO
    TITLE "Суп Харчо - В лучшем случае"
    INDEX 01 43:33:16
  TRACK 31 AUDIO
    TITLE "ДЖИНГЛ КОМЕТА ИИ ЛАУНЖ 12"
    INDEX 01 46:42:43
  TRACK 32 AUDIO
    TITLE "Денис Харламов - Жить"
    INDEX 01 46:53:20
  TRACK 33 AUDIO
    TITLE "ДЖИНГЛ КОМЕТА ИИ РОК 6"
    INDEX 01 50:03:40
  TRACK 34 AUDIO
    TITLE "Emin - Дай Мне Шанс"
    INDEX 01 50:09:26
  TRACK 35 AUDIO
    TITLE "rmxradio - novaya_volna_volgograd"
    INDEX 01 53:26:74
  TRACK 36 AUDIO
    TITLE "Юрий Цейтлин - Люблю тебя далекую"
    INDEX 01 53:34:25
  TRACK 37 AUDIO
    TITLE "ROLIK ГЕРОИ НАШЕГО ВРЕМЕНИ №56 (СКАЙ)"
    INDEX 01 56:54:28
  TRACK 38 AUDIO
    TITLE "ДОБИВКА ЧАСА РАДИО КОМЕТА НОЧЬ ИИ"
    INDEX 01 58:05:66
