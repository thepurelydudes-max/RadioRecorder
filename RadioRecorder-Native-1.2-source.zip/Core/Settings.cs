using System.Text.Json;
using System.Text.Json.Serialization;

namespace RadioRecorder.Core;

public sealed class Settings
{
    [JsonPropertyName("source")] public string Source { get; set; } = "";
    [JsonPropertyName("source_kind")] public string SourceKind { get; set; } = "device";
    [JsonPropertyName("stream_url")] public string StreamUrl { get; set; } = "http://192.168.2.170:8000/";
    [JsonPropertyName("folder")] public string Folder { get; set; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyMusic), "RadioRecorder");
    [JsonPropertyName("filename_format")] public string FilePattern { get; set; } = "%d-%m-%y_%hh-%mm";
    [JsonPropertyName("bitrate")] public int Bitrate { get; set; } = 128;
    [JsonPropertyName("sample_rate")] public int SampleRate { get; set; } = 48000;
    [JsonPropertyName("channels")] public int Channels { get; set; } = 1;
    [JsonPropertyName("split_enabled")] public bool SplitEnabled { get; set; } = true;
    [JsonPropertyName("split_minutes")] public int SplitMinutes { get; set; } = 60;
    [JsonPropertyName("metadata_mode")] public string MetadataMode { get; set; } = "api";
    [JsonPropertyName("metadata_api_url")] public string ApiUrl { get; set; } = "http://192.168.2.170:9001";
    [JsonPropertyName("metadata_icy_url")] public string IcyUrl { get; set; } = "http://192.168.2.170:8000/";
    [JsonPropertyName("metadata_username")] public string ApiUsername { get; set; } = "";
    [JsonPropertyName("metadata_password")] public string ApiPassword { get; set; } = "";
    [JsonPropertyName("cue_shift_sec")] public double CueShift { get; set; }
    [JsonPropertyName("monitor_device")] public string MonitorDevice { get; set; } = "Default";
    [JsonPropertyName("monitor_input")] public string MonitorInput { get; set; } = "Auto";
    [JsonPropertyName("retention_enabled")] public bool RetentionEnabled { get; set; } = true;
    [JsonPropertyName("retention_days")] public int RetentionDays { get; set; } = 365;
    [JsonPropertyName("auto_schedule")] public bool AutoSchedule { get; set; }
    [JsonPropertyName("schedule")] public bool[][] Schedule { get; set; } = MakeSchedule();
    [JsonPropertyName("start_with_windows")] public bool StartWithWindows { get; set; }
    [JsonPropertyName("minimize_on_start")] public bool MinimizeOnStart { get; set; }
    [JsonPropertyName("ask_on_exit")] public bool AskOnExit { get; set; } = true;
    [JsonPropertyName("reboot_on_error")] public bool RestartOnError { get; set; } = true;
    [JsonPropertyName("instance_name")] public string InstanceName { get; set; } = "";

    public static bool[][] MakeSchedule() => Enumerable.Range(0, 7).Select(_ => Enumerable.Repeat(true, 24).ToArray()).ToArray();
    public static string DataDirectory => AppContext.BaseDirectory;
    public static string PathName => Path.Combine(DataDirectory, "settings.json");
    public static Settings Load()
    {
        try
        {
            if (File.Exists(PathName))
            {
                var settings = JsonSerializer.Deserialize<Settings>(File.ReadAllText(PathName));
                if (settings != null)
                {
                    settings.Schedule = NormalizeSchedule(settings.Schedule);
                    return settings;
                }
            }
        }
        catch (Exception) { /* First run, damaged file or inaccessible location: use defaults. */ }
        return new Settings();
    }
    private static bool[][] NormalizeSchedule(bool[][]? schedule)
    {
        if (schedule?.Length != 7 || schedule.Any(r => r?.Length != 24)) return MakeSchedule();
        return schedule;
    }
    public void Save()
    {
        Directory.CreateDirectory(DataDirectory);
        string temp = PathName + ".tmp";
        File.WriteAllText(temp, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
        File.Move(temp, PathName, true);
    }
    public Settings Clone() => JsonSerializer.Deserialize<Settings>(JsonSerializer.Serialize(this))!;
    public bool IsScheduled(DateTime now)
    {
        int mondayFirst = ((int)now.DayOfWeek + 6) % 7;
        return Schedule[mondayFirst][now.Hour];
    }
    public bool ShouldAutoStart(DateTime now, DateTime? pausedUntil) => AutoSchedule && IsScheduled(now) && (!pausedUntil.HasValue || now >= pausedUntil.Value);
    public static DateTime NextClockHour(DateTime now) => new(now.Year, now.Month, now.Day, now.Hour, 0, 0, now.Kind) + TimeSpan.FromHours(1);
}
