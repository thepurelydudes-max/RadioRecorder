using System.Diagnostics;
using System.Globalization;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Channels;
using NAudio.CoreAudioApi;
using NAudio.Wave;

namespace RadioRecorder.Core;

public sealed class RecorderService : IDisposable
{
    private readonly object gate = new();
    private readonly Action<string> log;
    private Settings settings = new();
    private Process? process;
    private WasapiCapture? capture;
    private MMDevice? captureDevice;
    private Channel<byte[]>? audioQueue;
    private Task? audioPump;
    private DateTime lastDroppedAudioWarning = DateTime.MinValue;
    private DateTime startTime;
    private readonly HashSet<string> knownPaths = new(StringComparer.OrdinalIgnoreCase);
    private readonly List<Segment> segments = [];
    private readonly List<TrackEvent> tracks = [];
    private string initialTitle = "Неизвестный трек";
    private DateTime nextAttempt = DateTime.MinValue;
    private string sessionSuffix = "";
    private bool stopping;
    private DateTime lastGrowth;
    private long lastBytes;
    private string lastCleanupDate = "";
    private string lastError = "";
    public double LevelDb { get; private set; } = -60;
    public bool Running { get; private set; }
    public TimeSpan Elapsed => Running ? DateTime.Now - startTime : TimeSpan.Zero;
    public string? CurrentMp3 { get { lock (gate) return segments.LastOrDefault()?.Path; } }
    private sealed record Segment(string Path, DateTime Started);
    public RecorderService(Action<string> log) { this.log = log; }
    private static string ExpandPattern(string p, bool ffmpeg)
    {
        if (string.IsNullOrWhiteSpace(p) || p.Contains("..") || p.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
            throw new ArgumentException("Укажи безопасный шаблон имени файла");
        var table = ffmpeg
            ? new Dictionary<string, string> { ["%hh"] = "%H", ["%mm"] = "%M", ["%ss"] = "%S", ["%y"] = "%Y", ["%m"] = "%m", ["%d"] = "%d" }
            : new Dictionary<string, string> { ["%hh"] = "HH", ["%mm"] = "mm", ["%ss"] = "ss", ["%y"] = "yyyy", ["%m"] = "MM", ["%d"] = "dd" };
        string rewritten = Regex.Replace(p, "%hh|%mm|%ss|%y|%m|%d", m => table[m.Value]);
        if (Regex.IsMatch(rewritten, "%[a-zA-Z]" ) && !ffmpeg)
            throw new ArgumentException("Неизвестная переменная в имени файла");
        if (!ffmpeg && rewritten.Contains('%')) throw new ArgumentException("Недопустимый шаблон имени файла");
        if (ffmpeg && Regex.IsMatch(rewritten, "%(?![YmdHMS])")) throw new ArgumentException("Недопустимый формат имени файла");
        if (!p.Contains('%')) throw new ArgumentException("В шаблоне должны быть дата и время");
        return rewritten;
    }
    public static string Preview(Settings s, DateTime at) => at.ToString(ExpandPattern(s.FilePattern, false), CultureInfo.InvariantCulture) + ".mp3";
    public void Start(Settings s, string firstTitle)
    {
        lock (gate)
        {
            if (Running) return;
            if (!AudioDevices.IsFfmpegAvailable) throw new FileNotFoundException("ffmpeg.exe отсутствует рядом с RadioRecorder.exe");
            if (s.SourceKind == "device" && string.IsNullOrWhiteSpace(s.Source)) throw new ArgumentException("Выбери устройство записи");
            if (s.SourceKind == "stream" && string.IsNullOrWhiteSpace(s.StreamUrl)) throw new ArgumentException("Укажи адрес HTTP-потока");
            if (s.SplitEnabled && s.SplitMinutes is < 1 or > 1440) throw new ArgumentException("Разделение: допустимо 1–1440 минут");
            if (s.SampleRate is not (32000 or 44100 or 48000)) throw new ArgumentException("Частота записи не поддерживается");
            if (s.Bitrate is < 32 or > 320 || s.Channels is < 1 or > 2) throw new ArgumentException("Недопустимые параметры MP3");
            settings = s.Clone();
            Directory.CreateDirectory(settings.Folder);
            startTime = DateTime.Now;
            knownPaths.Clear();
            foreach (var file in Directory.EnumerateFiles(settings.Folder, "*.mp3")) knownPaths.Add(file);
            tracks.Clear(); segments.Clear();
            initialTitle = string.IsNullOrWhiteSpace(firstTitle) ? "Неизвестный трек" : firstTitle;
            lastError = ""; lastCleanupDate = ""; stopping = false; nextAttempt = DateTime.MinValue;
            int suffixNumber = 1;
            while (true)
            {
                sessionSuffix = suffixNumber == 1 ? "" : "_part" + suffixNumber;
                string candidate = Path.Combine(settings.Folder,
                    Path.GetFileNameWithoutExtension(Preview(settings, startTime)) + sessionSuffix + ".mp3");
                if (!File.Exists(candidate)) break;
                suffixNumber++;
                if (suffixNumber > 100000) throw new IOException("Слишком много файлов с таким названием");
            }
            SpawnProcess();
            Running = true;
            lastGrowth = DateTime.Now; lastBytes = 0;
            log("Запись запущена");
        }
    }
    // Capture devices use Windows WASAPI; FFmpeg receives RAW PCM through
    // stdin. This makes Windows endpoint IDs valid regardless of DirectShow.
    // HTTP audio source keeps the pre-existing FFmpeg URL path untouched.
    private void SpawnProcess()
    {
        StopCapturePipeline();
        WasapiCapture? newCapture = null;
        MMDevice? newDevice = null;
        WaveFormat? format = null;
        bool windowsInput = settings.SourceKind == "device";
        try
        {
            if (windowsInput)
            {
                newDevice = AudioDevices.OpenCapture(settings.Source);
                newCapture = new WasapiCapture(newDevice);
                format = AudioLevel.NormalizeFormat(newCapture.WaveFormat);
            }
            string name = ExpandPattern(settings.FilePattern, true) + sessionSuffix + ".mp3";
            var args = new List<string> { "-hide_banner", "-loglevel", "info", "-n", "-thread_queue_size", "1024" };
            if (windowsInput)
            {
                args.AddRange(["-nostdin", "-f", AudioLevel.FfmpegInputFormat(format!),
                    "-ar", format!.SampleRate.ToString(CultureInfo.InvariantCulture),
                    "-ac", format.Channels.ToString(CultureInfo.InvariantCulture), "-i", "pipe:0"]);
            }
            else args.AddRange(["-i", settings.StreamUrl]);
            args.AddRange(["-map", "0:a:0", "-vn", "-ac", settings.Channels.ToString(),
                "-ar", settings.SampleRate.ToString(), "-af", "ebur128=peak=true",
                "-c:a", "libmp3lame", "-b:a", settings.Bitrate + "k"]);
            if (settings.SplitEnabled)
                args.AddRange(["-f", "segment", "-segment_format", "mp3", "-segment_time",
                    (settings.SplitMinutes * 60).ToString(), "-segment_atclocktime", "1",
                    "-reset_timestamps", "1", "-strftime", "1", Path.Combine(settings.Folder, name)]);
            else
                args.AddRange(["-f", "mp3", Path.Combine(settings.Folder,
                    Path.GetFileNameWithoutExtension(Preview(settings, DateTime.Now)) + sessionSuffix + ".mp3")]);
            var psi = new ProcessStartInfo(AudioDevices.Ffmpeg)
            {
                UseShellExecute = false, CreateNoWindow = true,
                RedirectStandardError = true, RedirectStandardInput = true,
                RedirectStandardOutput = false,
                StandardErrorEncoding = System.Text.Encoding.UTF8
            };
            foreach (string a in args) psi.ArgumentList.Add(a);
            var p = new Process { StartInfo = psi, EnableRaisingEvents = true };
            try
            {
                p.Start();
                p.ErrorDataReceived += (_, e) => { if (e.Data is { } line) ProcessLog(line); };
                p.BeginErrorReadLine();
                process = p;
                if (windowsInput)
                {
                    // Audio callbacks must never block waiting for encoding or disk IO.
                    var queue = Channel.CreateBounded<byte[]>(new BoundedChannelOptions(256)
                    {
                        SingleReader = true, SingleWriter = true, FullMode = BoundedChannelFullMode.Wait
                    });
                    audioQueue = queue;
                    captureDevice = newDevice;
                    capture = newCapture;
                    var capturedFormat = format!;
                    newCapture!.DataAvailable += (_, e) =>
                    {
                        if (stopping || e.BytesRecorded <= 0) return;
                        var pcm = e.Buffer.AsSpan(0, e.BytesRecorded).ToArray();
                        if (!queue.Writer.TryWrite(pcm) && DateTime.Now - lastDroppedAudioWarning > TimeSpan.FromMinutes(1))
                        {
                            lastDroppedAudioWarning = DateTime.Now;
                            log("Переполнение очереди аудио: проверь нагрузку CPU/диска");
                        }
                        LevelDb = AudioLevel.PeakDb(e.Buffer, e.BytesRecorded, capturedFormat);
                    };
                    newCapture.RecordingStopped += (_, e) =>
                    {
                        queue.Writer.TryComplete();
                        if (e.Exception != null) log("Аудиовход отключился: " + e.Exception.Message);
                    };
                    audioPump = Task.Run(async () =>
                    {
                        try
                        {
                            await foreach (var block in queue.Reader.ReadAllAsync())
                                await p.StandardInput.BaseStream.WriteAsync(block);
                            await p.StandardInput.BaseStream.FlushAsync();
                        }
                        catch (Exception ex) when (ex is IOException or InvalidOperationException or ObjectDisposedException)
                        { /* FFmpeg exited or was stopped */ }
                        finally
                        {
                            try { p.StandardInput.Close(); } catch { }
                        }
                    });
                    newCapture.StartRecording();
                    newCapture = null;
                    newDevice = null;
                }
            }
            catch
            {
                StopCapturePipeline();
                try { if (!p.HasExited) p.Kill(entireProcessTree: true); } catch { }
                p.Dispose();
                process = null;
                throw;
            }
        }
        finally
        {
            newCapture?.Dispose();
            newDevice?.Dispose();
        }
    }

    private void StopCapturePipeline()
    {
        var localCapture = capture;
        capture = null;
        try { localCapture?.StopRecording(); } catch { }
        audioQueue?.Writer.TryComplete();
        // Complete the last RAW PCM samples before closing stdin: FFmpeg will
        // finish and finalize the current MP3 segment on pipe EOF.
        try { audioPump?.Wait(TimeSpan.FromSeconds(4)); } catch { }
        audioPump = null;
        audioQueue = null;
        localCapture?.Dispose();
        captureDevice?.Dispose();
        captureDevice = null;
    }

    private void ProcessLog(string line)
    {
        var meter = Regex.Match(line, @"FTPK:\s*(-?\d+(?:\.\d+)?)", RegexOptions.CultureInvariant);
        if (meter.Success && double.TryParse(meter.Groups[1].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out var db))
            LevelDb = db;
        if (line.Contains("Error", StringComparison.OrdinalIgnoreCase) || line.Contains("Could not", StringComparison.OrdinalIgnoreCase) ||
            line.Contains("No such device", StringComparison.OrdinalIgnoreCase) || line.Contains("already exists", StringComparison.OrdinalIgnoreCase))
        {
            string trimmed = line.Trim();
            if (trimmed != lastError) { lastError = trimmed; log("FFmpeg: " + trimmed[..Math.Min(220, trimmed.Length)]); }
        }
    }
    private static DateTime Boundary(DateTime now, int minutes)
    {
        var day = now.Date;
        return day.AddMinutes((int)(now - day).TotalMinutes / minutes * minutes);
    }
    public void Tick()
    {
        lock (gate)
        {
            if (!Running || stopping) return;
            if (process == null || process.HasExited)
            {
                if (!settings.RestartOnError) { log("FFmpeg завершился; запись остановлена"); Stop(); return; }
                if (DateTime.Now >= nextAttempt)
                {
                    nextAttempt = DateTime.Now.AddSeconds(5);
                    try
                    {
                        StopCapturePipeline();
                        process?.Dispose();
                        process = null;
                        // Restart must use a fresh part suffix to avoid overwriting current-hour files.
                        sessionSuffix = "_part" + DateTime.Now.ToString("HHmmss", CultureInfo.InvariantCulture);
                        SpawnProcess();
                        log("FFmpeg переподключён");
                    }
                    catch (Exception e) { log("Ошибка перезапуска: " + e.Message); }
                }
                return;
            }
            ScanSegments();
            if (segments.Count > 0)
            {
                long len = 0;
                try { len = new FileInfo(segments[^1].Path).Length; } catch (IOException) { }
                if (len != lastBytes) { lastBytes = len; lastGrowth = DateTime.Now; }
                else if ((DateTime.Now - lastGrowth).TotalSeconds > 45)
                {
                    log("Запись не растёт больше 45 секунд: попытка переподключения");
                    try { process.Kill(); } catch { }
                    lastGrowth = DateTime.Now;
                }
            }
            CleanupIfDue();
        }
    }
    private void ScanSegments()
    {
        var fresh = Directory.EnumerateFiles(settings.Folder, "*.mp3")
            .Where(p => !knownPaths.Contains(p) && new FileInfo(p).Length > 0)
            .OrderBy(p => File.GetCreationTime(p)).ToList();
        foreach (string file in fresh)
        {
            knownPaths.Add(file);
            DateTime started = segments.Count == 0 ? startTime : Boundary(DateTime.Now, settings.SplitMinutes);
            if (segments.Count > 0 && started <= segments[^1].Started)
                started = DateTime.Now > segments[^1].Started ? DateTime.Now : segments[^1].Started.AddMilliseconds(10);
            segments.Add(new Segment(file, started));
            if (segments.Count > 4)
            {
                segments.RemoveAt(0);
                var carry = tracks.Where(e => e.At <= segments[0].Started).LastOrDefault();
                tracks.RemoveAll(e => e.At < segments[0].Started);
                if (carry != null) { tracks.Insert(0, carry); initialTitle = carry.Title; }
            }
            log("Новый MP3: " + Path.GetFileName(file));
            WriteCues();
        }
    }
    public void AddTrack(TrackEvent value)
    {
        lock (gate)
        {
            if (!Running) return;
            var e = value with { At = value.At.AddSeconds(settings.CueShift) };
            if (tracks.Any(t => t.At == e.At && t.Title == e.Title)) return;
            tracks.Add(e);
            tracks.Sort((a, b) => a.At.CompareTo(b.At));
            WriteCues();
            log("CUE: " + e.Title);
        }
    }
    private void WriteCues()
    {
        for (int i = 0; i < segments.Count; i++)
        {
            var seg = segments[i];
            DateTime end = i + 1 < segments.Count ? segments[i + 1].Started : DateTime.Now.AddDays(1);
            try { Cue.SaveAtomic(Path.ChangeExtension(seg.Path, ".cue"), Cue.Generate(Path.GetFileName(seg.Path), seg.Started, end, tracks, initialTitle)); }
            catch (Exception e) { log("CUE не записан: " + e.Message); }
        }
    }
    public void Stop()
    {
        lock (gate)
        {
            if (!Running || stopping) return;
            stopping = true;
            try
            {
                StopCapturePipeline();
                if (process is { HasExited: false } p)
                {
                    if (settings.SourceKind != "device")
                    {
                        try { p.StandardInput.WriteLine("q"); p.StandardInput.Flush(); }
                        catch (IOException) { }
                    }
                    if (!p.WaitForExit(6000)) { p.Kill(entireProcessTree: true); p.WaitForExit(1500); }
                }
                ScanSegments(); WriteCues();
            }
            catch (Exception e) { log("Завершение записи: " + e.Message); }
            finally
            {
                StopCapturePipeline();
                process?.Dispose(); process = null;
                Running = false; stopping = false;
                log("Запись остановлена");
            }
        }
    }
    private void CleanupIfDue()
    {
        if (!settings.RetentionEnabled || !Running) return;
        string date = DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        if (lastCleanupDate == date) return;
        string archive = Path.GetFullPath(settings.Folder).TrimEnd(Path.DirectorySeparatorChar);
        string app = Path.GetFullPath(AppContext.BaseDirectory).TrimEnd(Path.DirectorySeparatorChar);
        string home = Path.GetFullPath(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)).TrimEnd(Path.DirectorySeparatorChar);
        string root = Path.GetPathRoot(archive)!.TrimEnd(Path.DirectorySeparatorChar);
        // Reject system/user-critical folders and junctions. Retention is destructive, not Recycle Bin.
        var protectedFolders = new[]
        {
            Environment.GetFolderPath(Environment.SpecialFolder.Windows),
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
            Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            Environment.GetFolderPath(Environment.SpecialFolder.MyMusic),
            Environment.GetFolderPath(Environment.SpecialFolder.MyPictures),
            Path.Combine(home, "Downloads")
        };
        bool prohibited = protectedFolders.Where(p => !string.IsNullOrWhiteSpace(p))
            .Select(p => Path.GetFullPath(p).TrimEnd(Path.DirectorySeparatorChar))
            .Any(p => archive.Equals(p, StringComparison.OrdinalIgnoreCase) ||
                      ((p.Equals(Environment.GetFolderPath(Environment.SpecialFolder.Windows), StringComparison.OrdinalIgnoreCase) ||
                        p.Equals(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), StringComparison.OrdinalIgnoreCase) ||
                        p.Equals(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), StringComparison.OrdinalIgnoreCase)) &&
                       archive.StartsWith(p + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)));
        DirectoryInfo? cursor = new(archive);
        while (cursor != null && !prohibited)
        {
            try { if ((cursor.Attributes & FileAttributes.ReparsePoint) != 0) prohibited = true; }
            catch { prohibited = true; }
            cursor = cursor.Parent;
        }
        if (prohibited || settings.RetentionDays is < 1 or > 3650 || archive.Equals(root, StringComparison.OrdinalIgnoreCase) ||
            archive.Equals(home, StringComparison.OrdinalIgnoreCase) || archive.Equals(app, StringComparison.OrdinalIgnoreCase) ||
            app.StartsWith(archive + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
        {
            log("Автоочистка отключена для небезопасной папки / неверного срока хранения");
            lastCleanupDate = date;
            return;
        }
        string stateFile = Path.Combine(AppContext.BaseDirectory, "retention_state.json");
        try
        {
            if (File.Exists(stateFile))
            {
                using var state = JsonDocument.Parse(File.ReadAllText(stateFile));
                if (state.RootElement.TryGetProperty("folder", out var f) && f.GetString() == archive &&
                    state.RootElement.TryGetProperty("date", out var d) && d.GetString() == date)
                { lastCleanupDate = date; return; }
            }
            var exclude = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var seg in segments) { exclude.Add(seg.Path); exclude.Add(Path.ChangeExtension(seg.Path, ".cue")); }
            int removed = 0;
            DateTime cutoff = DateTime.Today.AddDays(-settings.RetentionDays);
            foreach (string path in Directory.EnumerateFiles(archive, "*", SearchOption.TopDirectoryOnly))
            {
                try
                {
                    FileAttributes a = File.GetAttributes(path);
                    if ((a & FileAttributes.ReparsePoint) != 0 || exclude.Contains(path) ||
                        File.GetLastWriteTime(path) >= cutoff) continue;
                    File.Delete(path);
                    removed++;
                }
                catch (IOException ex) { log("Автоочистка: " + ex.Message); }
                catch (UnauthorizedAccessException ex) { log("Автоочистка: " + ex.Message); }
            }
            string temp = stateFile + ".tmp";
            File.WriteAllText(temp, JsonSerializer.Serialize(new { folder = archive, date }));
            File.Move(temp, stateFile, true);
            lastCleanupDate = date;
            log($"Ежедневная очистка архива: удалено {removed} файлов");
        }
        catch (Exception e) { log("Автоочистка не завершилась: " + e.Message); }
    }
    public void Dispose() => Stop();
}
