using System.Text;

namespace RadioRecorder.Core;

public sealed record TrackEvent(DateTime At, string Title, string Source);

public static class Cue
{
    private static readonly UTF8Encoding Utf8Bom = new(true);
    public static string Time(double seconds)
    {
        long frames = Math.Max(0, (long)Math.Round(seconds * 75.0, MidpointRounding.ToEven));
        long mins = frames / 4500;
        long secs = (frames % 4500) / 75;
        long frame = frames % 75;
        return $"{mins:00}:{secs:00}:{frame:00}";
    }
    public static string Safe(string text) => text.Replace('"', '\'').Replace('\r', ' ').Replace('\n', ' ').Replace('\t', ' ').Trim();

    public static string Generate(string fileName, DateTime started, DateTime ended, IEnumerable<TrackEvent> events, string initial = "Неизвестный трек")
    {
        var all = events.OrderBy(e => e.At).ToList();
        var previous = all.LastOrDefault(e => e.At <= started)?.Title ?? initial;
        var lines = new List<string>
        {
            $"REM DATE {started.Year}",
            "REM COMMENT  \"Created in RadioBOSS (Stream Archive)\"",
            $"FILE \"{Safe(fileName)}\" MP3",
            "  TRACK 01 AUDIO", $"    TITLE \"{Safe(previous)}\"", "    INDEX 01 00:00:00"
        };
        int index = 1;
        foreach (var e in all.Where(e => e.At > started && e.At < ended))
        {
            string title = e.Title.Trim();
            if (title.Length == 0 || title == previous) continue;
            if (++index > 99) break;
            lines.Add($"  TRACK {index:00} AUDIO");
            lines.Add($"    TITLE \"{Safe(title)}\"");
            lines.Add($"    INDEX 01 {Time((e.At - started).TotalSeconds)}");
            previous = title;
        }
        return string.Join("\r\n", lines) + "\r\n";
    }
    public static void SaveAtomic(string path, string contents)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        string temporary = path + ".writing";
        try
        {
            File.WriteAllText(temporary, contents, Utf8Bom);
            File.Move(temporary, path, true);
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }
}
