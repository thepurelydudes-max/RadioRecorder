using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace RadioRecorder.Core;

public sealed class MetadataService : IDisposable
{
    private readonly HttpClient http = new() { Timeout = TimeSpan.FromSeconds(12) };
    private CancellationTokenSource? cancel;
    private Task? task;
    private readonly Action<TrackEvent> onEvent;
    private readonly Action<string> log;
    private readonly HashSet<string> seen = new();
    public string LastTitle { get; private set; } = "Неизвестный трек";

    public MetadataService(Action<TrackEvent> onEvent, Action<string> log) { this.onEvent = onEvent; this.log = log; }
    public void Start(Settings settings)
    {
        Stop();
        seen.Clear();
        if (settings.MetadataMode == "none") return;
        cancel = new CancellationTokenSource();
        var token = cancel.Token;
        task = Task.Run(() => settings.MetadataMode == "icy" ? RunIcy(settings, token) : RunApi(settings, token), token);
    }
    public void Stop()
    {
        cancel?.Cancel();
        cancel?.Dispose();
        cancel = null;
        task = null;
    }
    private static string TrackTitle(XElement track)
    {
        string attr(string name) => (string?)track.Attribute(name) ?? "";
        string cast = attr("CASTTITLE").Trim();
        if (cast.Length > 0) return cast;
        string artist = attr("ARTIST").Trim();
        string title = attr("TITLE").Trim();
        if (artist.Length > 0 || title.Length > 0) return string.Join(" - ", new[] { artist, title }.Where(s => s.Length > 0));
        return Path.GetFileNameWithoutExtension(attr("FILENAME").Replace('\\', '/'));
    }
    public static List<TrackEvent> ParseLastPlayed(string xml)
    {
        var result = new List<TrackEvent>();
        foreach (XElement tr in XDocument.Parse(xml).Descendants("TRACK"))
        {
            if (!DateTime.TryParseExact((string?)tr.Attribute("STARTTIME"), "yyyy-MM-dd HH:mm:ss",
                System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out var at)) continue;
            string title = TrackTitle(tr);
            if (title.Length != 0) result.Add(new TrackEvent(at, title, "API lastplayed"));
        }
        return result.OrderBy(e => e.At).ToList();
    }
    public static TrackEvent? ParsePlaybackInfo(string xml, DateTime now)
    {
        var doc = XDocument.Parse(xml);
        var tr = doc.Descendants("CurrentTrack").Elements("TRACK").FirstOrDefault();
        if (tr is null) return null;
        var playback = doc.Descendants("Playback").FirstOrDefault();
        string state = ((string?)playback?.Attribute("state") ?? "play").ToLowerInvariant();
        if (state is not ("play" or "playing")) return null;
        string title = TrackTitle(tr);
        if (title.Length == 0) return null;
        long.TryParse((string?)playback?.Attribute("pos"), out long ms);
        return new TrackEvent(now.AddMilliseconds(-Math.Max(0, ms)), title, "API playbackinfo");
    }
    private void Emit(TrackEvent ev)
    {
        // API history may re-send identical entries; ICY comes only on title changes.
        string key = $"{ev.At.Ticks}/{ev.Title}";
        if (!seen.Add(key)) return;
        if (seen.Count > 3000) seen.Clear();
        LastTitle = ev.Title;
        onEvent(ev);
    }
    private static Uri Url(Settings s, string action)
    {
        string uri = s.ApiUrl.TrimEnd('/') + "/?pass=" + Uri.EscapeDataString(s.ApiPassword) +
                     "&action=" + Uri.EscapeDataString(action);
        if (s.ApiUsername.Length > 0) uri += "&user=" + Uri.EscapeDataString(s.ApiUsername);
        return new Uri(uri);
    }
    private async Task RunApi(Settings s, CancellationToken ct)
    {
        string previousError = "";
        while (!ct.IsCancellationRequested)
        {
            try
            {
                var play = http.GetStringAsync(Url(s, "playbackinfo"), ct);
                var history = http.GetStringAsync(Url(s, "getlastplayed"), ct);
                await Task.WhenAll(play, history);
                var recent = ParseLastPlayed(history.Result)
                    .Where(e => e.At >= DateTime.Now.AddHours(-2) && e.At < DateTime.Now.AddMinutes(1)).ToList();
                foreach (var e in recent) Emit(e);
                TrackEvent? current = ParsePlaybackInfo(play.Result, DateTime.Now);
                if (current is not null && !recent.Any(e => e.Title == current.Title && Math.Abs((e.At - current.At).TotalSeconds) < 3)
                    && LastTitle != current.Title)
                    Emit(current);
                if (previousError.Length > 0) log("Связь с RadioBOSS API восстановлена");
                previousError = "";
                await Task.Delay(2000, ct);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested) { break; }
            catch (Exception e)
            {
                string msg = $"API RadioBOSS: {e.GetType().Name}: {e.Message}";
                if (msg != previousError) log(msg);
                previousError = msg;
                try { await Task.Delay(5000, ct); } catch (OperationCanceledException) { break; }
            }
        }
    }
    private static async Task ReadFully(Stream stream, byte[] buffer, int count, CancellationToken ct)
    {
        int n = 0;
        while (n < count)
        {
            int read = await stream.ReadAsync(buffer.AsMemory(n, count - n), ct);
            if (read == 0) throw new EndOfStreamException("Соединение с потоком прервано");
            n += read;
        }
    }
    private async Task RunIcy(Settings s, CancellationToken ct)
    {
        string previousError = "";
        while (!ct.IsCancellationRequested)
        {
            try
            {
                using var req = new HttpRequestMessage(HttpMethod.Get, s.IcyUrl);
                req.Headers.TryAddWithoutValidation("Icy-MetaData", "1");
                using var response = await http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);
                response.EnsureSuccessStatusCode();
                if (!response.Headers.TryGetValues("icy-metaint", out var values) ||
                    !int.TryParse(values.FirstOrDefault(), out int interval) || interval is < 1 or > 20_000_000)
                    throw new InvalidDataException("HTTP-поток не предоставляет icy-metaint");
                await using var stream = await response.Content.ReadAsStreamAsync(ct);
                byte[] buffer = new byte[16384];
                string titleLast = "";
                log("ICY подключён: аудиобайты отбрасываются, принимаются только названия");
                previousError = "";
                while (!ct.IsCancellationRequested)
                {
                    int remaining = interval;
                    while (remaining > 0)
                    {
                        int len = Math.Min(remaining, buffer.Length);
                        await ReadFully(stream, buffer, len, ct);
                        remaining -= len;
                    }
                    byte[] size = new byte[1];
                    await ReadFully(stream, size, 1, ct);
                    int metadataLength = size[0] * 16;
                    if (metadataLength == 0) continue;
                    byte[] data = new byte[metadataLength];
                    await ReadFully(stream, data, data.Length, ct);
                    string block;
                    try { block = new UTF8Encoding(false, true).GetString(data).TrimEnd('\0'); }
                    catch (DecoderFallbackException)
                    {
                        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
                        block = Encoding.GetEncoding(1251).GetString(data).TrimEnd('\0');
                    }
                    var match = Regex.Match(block, "StreamTitle='(.*?)';", RegexOptions.Singleline);
                    if (match.Success && match.Groups[1].Value.Trim() is { Length: > 0 } title && title != titleLast)
                    {
                        titleLast = title;
                        Emit(new TrackEvent(DateTime.Now, title, "ICY"));
                    }
                }
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested) { break; }
            catch (Exception ex)
            {
                string msg = "ICY: " + ex.Message;
                if (msg != previousError) log(msg);
                previousError = msg;
                try { await Task.Delay(5000, ct); } catch (OperationCanceledException) { break; }
            }
        }
    }
    public void Dispose() { Stop(); http.Dispose(); }
}
