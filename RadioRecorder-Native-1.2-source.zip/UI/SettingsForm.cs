using System.Drawing;
using RadioRecorder.Core;
using NAudio.Wave;

namespace RadioRecorder.UI;

public sealed class SettingsForm : Form
{
    private readonly Settings original;
    public Settings Value { get; private set; }
    private readonly ComboBox source = new() { Width = 440, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly Label deviceStatus = new() { AutoSize = true, ForeColor = Color.DimGray, MaximumSize = new Size(480, 0) };
    private bool scanningDevices;
    private readonly ComboBox sourceKind = new() { Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly TextBox streamUrl = new() { Width = 450 };
    private readonly TextBox folder = new() { Width = 430 };
    private readonly TextBox pattern = new() { Width = 320 };
    private readonly ComboBox bitrate = new() { Width = 110, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly ComboBox sampleRate = new() { Width = 110, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly ComboBox channels = new() { Width = 110, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly CheckBox splitEnabled = new() { Text = "Разделять запись", AutoSize = true };
    private readonly NumericUpDown splitMinutes = new() { Minimum = 1, Maximum = 1440, Value = 60, Width = 100 };
    private readonly ComboBox output = new() { Width = 430, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly ComboBox input = new() { Width = 430, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly ComboBox metadataMode = new() { Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly TextBox apiUrl = new() { Width = 430 };
    private readonly TextBox username = new() { Width = 300 };
    private readonly TextBox password = new() { Width = 300, UseSystemPasswordChar = true };
    private readonly TextBox icyUrl = new() { Width = 430 };
    private readonly NumericUpDown cueShift = new() { Width = 110, Minimum = -300, Maximum = 300, DecimalPlaces = 2, Increment = 0.25m };
    private readonly CheckBox retention = new() { Text = "Удалять старые файлы автоматически", AutoSize = true };
    private readonly NumericUpDown retentionDays = new() { Width = 110, Minimum = 1, Maximum = 3650 };
    private readonly CheckBox startWindows = new() { Text = "Запускать вместе с Windows от администратора", AutoSize = true };
    private readonly CheckBox minimizeStart = new() { Text = "Свернуть при запуске", AutoSize = true };
    private readonly CheckBox askOnExit = new() { Text = "Спрашивать при выходе во время записи", AutoSize = true };
    private readonly CheckBox restartError = new() { Text = "Перезапускать запись при ошибке", AutoSize = true };
    private readonly Label preview = new() { AutoSize = true, ForeColor = Color.DimGray };

    public SettingsForm(Settings settings)
    {
        original = settings;
        Value = settings.Clone();
        Text = "Настройки — RadioRecorder";
        ClientSize = new Size(850, 630);
        MinimumSize = new Size(680, 525);
        StartPosition = FormStartPosition.CenterParent;
        Font = new Font("Segoe UI", 9.5f);
        ShowIcon = true;
        Icon = AppIcon.Load();
        var tabs = new TabControl { Dock = DockStyle.Fill };
        var pageAudio = Tab("Запись и воспроизведение");
        var pageMetadata = Tab("Метаданные / CUE");
        var pageArchive = Tab("Архив / Общие");
        tabs.TabPages.AddRange([pageAudio, pageMetadata, pageArchive]);
        var footer = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 49, FlowDirection = FlowDirection.RightToLeft, Padding = new Padding(8) };
        var ok = new Button { Text = "Сохранить", Width = 105, Height = 30 };
        var cancel = new Button { Text = "Отмена", Width = 100, Height = 30, DialogResult = DialogResult.Cancel };
        ok.Click += (_, _) => Save();
        footer.Controls.AddRange([ok, cancel]);
        Controls.Add(tabs); Controls.Add(footer);
        AcceptButton = ok; CancelButton = cancel;

        var a = Stack(pageAudio);
        Section(a, "Источник записи");
        sourceKind.Items.AddRange(["Устройство Windows", "HTTP аудиопоток"]);
        Row(a, "Тип источника:", sourceKind);
        Row(a, "Аудиовход Windows:", source);
        var discover = new Button { Text = "Обновить список входов", AutoSize = true };
        discover.Click += async (_, _) => await RefreshInputsAsync(discover, showError: true);
        Row(a, "", discover);
        Row(a, "Состояние устройств:", deviceStatus);
        Row(a, "Адрес потока (если выбран HTTP):", streamUrl);
        Section(a, "MP3 и деление по часам");
        Row(a, "Частота, Гц:", sampleRate);
        Row(a, "Битрейт, kbps:", bitrate);
        Row(a, "Каналы:", channels);
        Row(a, "", splitEnabled);
        Row(a, "Интервал разделения, минут:", splitMinutes);
        Section(a, "Прослушивание — кнопка ▶ Play");
        Row(a, "Вывод звука (наушники / колонки):", output);
        Row(a, "Вход для мониторинга:", input);
        Row(a, "", new Label { AutoSize = true, Text = "Auto: мониторинг использует выбранный вход записи.\nПри необходимости можно выбрать другой вход." });

        var m = Stack(pageMetadata);
        Section(m, "Информация о проигрываемых композициях");
        metadataMode.Items.AddRange(["RadioBOSS HTTP API", "ICY из HTTP-потока", "Без метаданных"]);
        Row(m, "Источник метаданных:", metadataMode);
        Row(m, "Адрес HTTP API RadioBOSS:", apiUrl);
        Row(m, "Пользователь API (необязательно):", username);
        Row(m, "Пароль API:", password);
        Row(m, "ICY-поток с метаданными:", icyUrl);
        Row(m, "Коррекция времени CUE, сек:", cueShift);
        Row(m, "", new Label { AutoSize = true, MaximumSize = new Size(700, 0), Text = "Звук может поступать из Line In, а названия — отдельно через RadioBOSS HTTP API. Формат CUE: UTF-8 BOM, CRLF, TRACK/TITLE/INDEX 01 (75 кадров/сек)." });

        var r = Stack(pageArchive);
        Section(r, "Папка с записями");
        var browse = new Button { Text = "Обзор...", AutoSize = true };
        browse.Click += (_, _) => { using var dlg = new FolderBrowserDialog(); dlg.SelectedPath = folder.Text; if (dlg.ShowDialog(this) == DialogResult.OK) folder.Text = dlg.SelectedPath; };
        Row(r, "Папка:", folder);
        Row(r, "", browse);
        Row(r, "Шаблон имени файла:", pattern);
        Row(r, "Пример:", preview);
        pattern.TextChanged += (_, _) => UpdatePreview();
        Section(r, "Ежедневная очистка после полуночи");
        Row(r, "", retention);
        Row(r, "Удалять файлы старше (дней):", retentionDays);
        Row(r, "", new Label { AutoSize = true, MaximumSize = new Size(700, 0), Text = "Удаляются ВСЕ старые файлы из этой папки без подпапок. Возраст считается по дате изменения. Для безопасности используй отдельную папку архива." });
        Section(r, "Поведение программы");
        Row(r, "", startWindows);
        Row(r, "", new Label { AutoSize = true, MaximumSize = new Size(700, 0), Text = "Для первоначальной настройки Windows попросит однократно подтвердить UAC. После этого RadioRecorder будет запускаться при входе с повышенными правами без дополнительных запросов. Учётная запись должна иметь права администратора." });
        Row(r, "", minimizeStart); Row(r, "", askOnExit); Row(r, "", restartError);
        LoadValues();
        Shown += async (_, _) => await RefreshInputsAsync(discover, showError: false);
    }
    private async Task RefreshInputsAsync(Button discover, bool showError)
    {
        if (scanningDevices) return;
        scanningDevices = true;
        discover.Enabled = false;
        deviceStatus.Text = "Поиск аудиовходов Windows...";
        try
        {
            string previouslySelected = (source.SelectedItem as RecordingInput)?.Selector ?? Value.Source;
            InputScanResult scan = await AudioDevices.FindInputsAsync();
            if (IsDisposed) return;
            source.BeginUpdate();
            try
            {
                source.Items.Clear();
                foreach (RecordingInput item in scan.Inputs) source.Items.Add(item);
                var match = scan.Inputs.FirstOrDefault(x =>
                    x.Selector.Equals(previouslySelected, StringComparison.OrdinalIgnoreCase) ||
                    x.Name.Equals(previouslySelected, StringComparison.OrdinalIgnoreCase) ||
                    (previouslySelected.Contains(x.Name, StringComparison.OrdinalIgnoreCase) && !AudioDevices.IsWindowsEndpoint(previouslySelected)));
                if (match is not null) source.SelectedItem = match;
                else if (source.Items.Count > 0)
                {
                    source.SelectedIndex = 0; // select a real, active Windows input
                    if (!string.IsNullOrWhiteSpace(previouslySelected))
                        deviceStatus.Text = "Прежний аудиовход недоступен: выбран первый доступный. Проверь его перед записью.";
                }
                // Keep the monitoring input dropdown synchronized with Windows.
                string monitoring = (input.SelectedItem as RecordingInput)?.Selector ?? Value.MonitorInput;
                input.Items.Clear();
                input.Items.Add(new RecordingInput("Auto (вход записи)", "Auto", "Auto"));
                foreach (var item in scan.Inputs) input.Items.Add(item);
                input.SelectedItem = input.Items.Cast<RecordingInput>()
                    .FirstOrDefault(x => x.Selector.Equals(monitoring, StringComparison.OrdinalIgnoreCase)) ?? input.Items[0];
            }
            finally { source.EndUpdate(); }
            string selected = (source.SelectedItem as RecordingInput)?.Name ?? "не выбран";
            deviceStatus.Text = scan.Inputs.Count > 0
                ? $"Обнаружено входов: {scan.Inputs.Count}. Текущий: {selected}" +
                  (AudioDevices.IsFfmpegAvailable ? "" : ". Для записи нужен ffmpeg.exe.")
                : "Входы не найдены. Проверь Windows → Параметры звука → Ввод.";
            if (scan.Inputs.Count == 0 && showError)
                MessageBox.Show(this, deviceStatus.Text + "\n" + scan.Diagnostics,
                    "Аудиовходы Windows", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else if (scan.Diagnostics.Length > 0)
                deviceStatus.Text += " (подробности: " + scan.Diagnostics.Replace(Environment.NewLine, " ") + ")";
        }
        catch (Exception ex)
        {
            deviceStatus.Text = "Ошибка обнаружения устройств: " + ex.Message;
            if (showError) MessageBox.Show(this, deviceStatus.Text, "Аудиовходы Windows", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            if (!IsDisposed) discover.Enabled = true;
            scanningDevices = false;
        }
    }

    private static TabPage Tab(string title) => new(title) { AutoScroll = true, BackColor = Color.White };
    private static FlowLayoutPanel Stack(TabPage page)
    {
        var panel = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, FlowDirection = FlowDirection.TopDown, WrapContents = false, Padding = new Padding(14), Width = 790 };
        page.Controls.Add(panel);
        return panel;
    }
    private static void Section(FlowLayoutPanel panel, string title)
    {
        panel.Controls.Add(new Label { Text = title, AutoSize = false, Size = new Size(760, 27), ForeColor = Color.FromArgb(137, 28, 34), Font = new Font("Segoe UI", 10f, FontStyle.Bold), Padding = new Padding(0, 8, 0, 0) });
    }
    private static void Row(FlowLayoutPanel panel, string label, Control input)
    {
        var row = new Panel { Width = 765, Height = input is Label lab && lab.Text.Contains('\n') ? 55 : 38 };
        var description = new Label { Text = label, AutoSize = false, Location = new Point(0, 8), Size = new Size(258, 27) };
        input.Location = new Point(261, input is CheckBox ? 7 : 3);
        row.Controls.Add(description); row.Controls.Add(input);
        panel.Controls.Add(row);
    }
    private void LoadValues()
    {
        var s = Value;
        sourceKind.SelectedIndex = s.SourceKind == "stream" ? 1 : 0;
        // The dropdown is populated as soon as this window becomes visible.
        // The saved selector is restored in RefreshInputsAsync.
        streamUrl.Text = s.StreamUrl;
        sampleRate.Items.AddRange(["32000", "44100", "48000"]);
        bitrate.Items.AddRange(["32", "64", "96", "128", "160", "192", "224", "256", "320"]);
        channels.Items.AddRange(["Моно", "Стерео"]);
        sampleRate.Text = s.SampleRate.ToString(); bitrate.Text = s.Bitrate.ToString();
        channels.SelectedIndex = s.Channels == 1 ? 0 : 1;
        splitEnabled.Checked = s.SplitEnabled; splitMinutes.Value = Math.Clamp(s.SplitMinutes, 1, 1440);
        output.Items.Add(new AudioOutput("Default", "Default"));
        try
        {
            foreach (AudioOutput d in AudioDevices.PlaybackOutputs()) output.Items.Add(d);
            var saved = output.Items.Cast<AudioOutput>().FirstOrDefault(d => d.Id == s.MonitorDevice || d.Name == s.MonitorDevice);
            output.SelectedItem = saved ?? output.Items[0];
        }
        catch (Exception e) { deviceStatus.Text = "Ошибка вывода Windows: " + e.Message; output.SelectedIndex = 0; }
        input.Items.Add(new RecordingInput("Auto (вход записи)", "Auto", "Auto"));
        try
        {
            foreach (RecordingInput d in AudioDevices.CaptureInputs()) input.Items.Add(d);
            var saved = input.Items.Cast<RecordingInput>().FirstOrDefault(d => d.Selector == s.MonitorInput || d.Name == s.MonitorInput);
            input.SelectedItem = saved ?? input.Items[0];
        }
        catch (Exception e) { deviceStatus.Text = "Ошибка входов Windows: " + e.Message; input.SelectedIndex = 0; }
        metadataMode.SelectedIndex = s.MetadataMode switch { "icy" => 1, "none" => 2, _ => 0 };
        apiUrl.Text = s.ApiUrl; username.Text = s.ApiUsername; password.Text = s.ApiPassword; icyUrl.Text = s.IcyUrl;
        cueShift.Value = Math.Clamp((decimal)s.CueShift, -300, 300);
        folder.Text = s.Folder; pattern.Text = s.FilePattern;
        retention.Checked = s.RetentionEnabled; retentionDays.Value = Math.Clamp(s.RetentionDays, 1, 3650);
        startWindows.Checked = s.StartWithWindows; minimizeStart.Checked = s.MinimizeOnStart;
        askOnExit.Checked = s.AskOnExit; restartError.Checked = s.RestartOnError;
        UpdatePreview();
    }
    private void UpdatePreview()
    {
        try { preview.Text = RecorderService.Preview(new Settings { FilePattern = pattern.Text }, DateTime.Now); }
        catch { preview.Text = "Неправильный формат имени"; }
    }
    private void Save()
    {
        try
        {
            Value.SourceKind = sourceKind.SelectedIndex == 1 ? "stream" : "device";
            if (Value.SourceKind == "device" && source.SelectedItem is not RecordingInput)
                throw new InvalidOperationException("Выбери вход записи Windows из списка устройств");
            Value.Source = source.SelectedItem is RecordingInput selectedInput ? selectedInput.Selector : original.Source;
            Value.StreamUrl = streamUrl.Text.Trim();
            Value.SampleRate = int.Parse(sampleRate.Text); Value.Bitrate = int.Parse(bitrate.Text);
            Value.Channels = channels.SelectedIndex == 0 ? 1 : 2;
            Value.SplitEnabled = splitEnabled.Checked; Value.SplitMinutes = (int)splitMinutes.Value;
            Value.MonitorDevice = (output.SelectedItem as AudioOutput)?.Id ?? "Default";
            Value.MonitorInput = (input.SelectedItem as RecordingInput)?.Selector ?? "Auto";
            Value.MetadataMode = metadataMode.SelectedIndex switch { 1 => "icy", 2 => "none", _ => "api" };
            Value.ApiUrl = apiUrl.Text.Trim(); Value.ApiUsername = username.Text.Trim(); Value.ApiPassword = password.Text;
            Value.IcyUrl = icyUrl.Text.Trim(); Value.CueShift = (double)cueShift.Value;
            Value.Folder = Path.GetFullPath(folder.Text.Trim());
            Value.FilePattern = pattern.Text.Trim(); _ = RecorderService.Preview(Value, DateTime.Now);
            Value.RetentionEnabled = retention.Checked; Value.RetentionDays = (int)retentionDays.Value;
            Value.StartWithWindows = startWindows.Checked; Value.MinimizeOnStart = minimizeStart.Checked;
            Value.AskOnExit = askOnExit.Checked; Value.RestartOnError = restartError.Checked;
            WindowsAutostart.Configure(Value.StartWithWindows);
            Value.Save();
            DialogResult = DialogResult.OK;
            Close();
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Ошибка настроек", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }
}
