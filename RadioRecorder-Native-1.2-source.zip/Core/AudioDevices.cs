using NAudio.CoreAudioApi;

namespace RadioRecorder.Core;

// These are real Windows audio endpoint IDs, not DirectShow labels. An endpoint
// can be captured by WASAPI even if FFmpeg doesn't list it under DirectShow.
public sealed record RecordingInput(string Name, string Selector, string Origin)
{
    public override string ToString() => Name;
}
public sealed record AudioOutput(string Name, string Id)
{
    public override string ToString() => Name;
}
public sealed record InputScanResult(IReadOnlyList<RecordingInput> Inputs, string Diagnostics);

public static class AudioDevices
{
    public const string WasapiPrefix = "wasapi:";
    public static string Ffmpeg => Path.Combine(AppContext.BaseDirectory, "ffmpeg.exe");
    public static bool IsFfmpegAvailable => File.Exists(Ffmpeg);
    public static bool IsWindowsEndpoint(string selector) => selector.StartsWith(WasapiPrefix, StringComparison.OrdinalIgnoreCase);

    public static IReadOnlyList<RecordingInput> CaptureInputs()
    {
        if (!OperatingSystem.IsWindows()) return [];
        using var enumerator = new MMDeviceEnumerator();
        var inputs = new List<RecordingInput>();
        // Windows Sound Settings > Input: active capture endpoints (Line In,
        // USB audio, VAC, microphones), using their unique endpoint IDs.
        foreach (var device in enumerator.EnumerateAudioEndPoints(DataFlow.Capture, DeviceState.Active))
        {
            using (device)
                inputs.Add(new RecordingInput(device.FriendlyName, WasapiPrefix + device.ID, "Windows WASAPI"));
        }
        return inputs;
    }

    public static IReadOnlyList<AudioOutput> PlaybackOutputs()
    {
        if (!OperatingSystem.IsWindows()) return [];
        using var enumerator = new MMDeviceEnumerator();
        var outputs = new List<AudioOutput>();
        foreach (var device in enumerator.EnumerateAudioEndPoints(DataFlow.Render, DeviceState.Active))
        {
            using (device) outputs.Add(new AudioOutput(device.FriendlyName, device.ID));
        }
        return outputs;
    }

    public static MMDevice OpenCapture(string selector)
    {
        if (!IsWindowsEndpoint(selector))
            throw new InvalidOperationException("Перевыбери источник записи в настройках: требуется аудиовход Windows WASAPI.");
        using var e = new MMDeviceEnumerator();
        var result = e.GetDevice(selector[WasapiPrefix.Length..]);
        if (result.DataFlow != DataFlow.Capture || result.State != DeviceState.Active)
        {
            result.Dispose();
            throw new InvalidOperationException("Аудиовход недоступен или отключён в Windows.");
        }
        return result;
    }

    public static MMDevice OpenPlayback(string value)
    {
        using var e = new MMDeviceEnumerator();
        if (string.IsNullOrWhiteSpace(value) || value == "Default")
            return e.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia);
        // Backwards compatibility: earlier settings stored a friendly name.
        try
        {
            var device = e.GetDevice(value);
            if (device.DataFlow == DataFlow.Render && device.State == DeviceState.Active) return device;
            device.Dispose();
        }
        catch (Exception) { }
        foreach (var device in e.EnumerateAudioEndPoints(DataFlow.Render, DeviceState.Active))
        {
            if (device.FriendlyName.Equals(value, StringComparison.OrdinalIgnoreCase)) return device;
            device.Dispose();
        }
        throw new InvalidOperationException("Выбранное устройство воспроизведения больше не доступно.");
    }

    public static async Task<InputScanResult> FindInputsAsync()
    {
        try
        {
            var inputs = await Task.Run(CaptureInputs);
            string diagnostic = IsFfmpegAvailable ? "" : "ffmpeg.exe не найден: для кодирования MP3 положи его рядом с RadioRecorder.exe";
            if (inputs.Count == 0) diagnostic = "Активных входных устройств нет. Проверь Параметры Windows → Система → Звук → Ввод и разрешения микрофона.";
            return new InputScanResult(inputs, diagnostic);
        }
        catch (Exception ex) { return new InputScanResult([], "Windows WASAPI: " + ex.Message); }
    }
}
