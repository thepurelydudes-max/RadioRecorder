using System.Diagnostics;
using NAudio.CoreAudioApi;
using NAudio.Wave;

namespace RadioRecorder.Core;

/// <summary>Independent WASAPI shared-mode monitoring, with a measured PCM peak meter.</summary>
public sealed class MonitorService : IDisposable
{
    private WasapiCapture? capture;
    private WasapiOut? output;
    private BufferedWaveProvider? buffer;
    private MMDevice? inDevice;
    private MMDevice? outDevice;
    private Process? decoder;
    private CancellationTokenSource? cancel;
    private int generation;
    private double levelDb = -60;
    public bool Running { get; private set; }
    public double LevelDb => Volatile.Read(ref levelDb);

    public void Start(Settings settings)
    {
        Stop();
        int session = Interlocked.Increment(ref generation);
        try
        {
            outDevice = AudioDevices.OpenPlayback(settings.MonitorDevice);
            WaveFormat format;
            if (settings.SourceKind == "stream")
                format = new WaveFormat(44100, 16, 2);
            else
            {
                string selector = settings.MonitorInput == "Auto" ? settings.Source : settings.MonitorInput;
                if (!AudioDevices.IsWindowsEndpoint(selector))
                    throw new InvalidOperationException("В настройках выбери действующий вход Windows для прослушивания.");
                inDevice = AudioDevices.OpenCapture(selector);
                capture = new WasapiCapture(inDevice);
                format = AudioLevel.NormalizeFormat(capture.WaveFormat);
                // A non-PCM shared mix format needs an explicit decoder, not blind buffer transfer.
                _ = AudioLevel.FfmpegInputFormat(format);
            }
            buffer = new BufferedWaveProvider(format) { DiscardOnBufferOverflow = true,
                BufferDuration = TimeSpan.FromSeconds(2) };
            output = new WasapiOut(outDevice, AudioClientShareMode.Shared, false, 120);
            output.Init(buffer);
            output.Play();
            Running = true;
            Volatile.Write(ref levelDb, -60);
            if (settings.SourceKind == "stream")
            {
                if (!AudioDevices.IsFfmpegAvailable) throw new FileNotFoundException("ffmpeg.exe не найден");
                var psi = new ProcessStartInfo(AudioDevices.Ffmpeg)
                {
                    UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true,
                    RedirectStandardError = true
                };
                foreach (string arg in new[] { "-hide_banner", "-loglevel", "error", "-i", settings.StreamUrl,
                    "-vn", "-f", "s16le", "-ac", "2", "-ar", "44100", "pipe:1" })
                    psi.ArgumentList.Add(arg);
                decoder = Process.Start(psi) ?? throw new IOException("Не запущен декодер потока");
                cancel = new CancellationTokenSource();
                var proc = decoder;
                var provider = buffer;
                var token = cancel.Token;
                _ = Task.Run(async () =>
                {
                    try
                    {
                        _ = proc.StandardError.ReadToEndAsync(token);
                        byte[] block = new byte[16384];
                        while (!token.IsCancellationRequested)
                        {
                            int count = await proc.StandardOutput.BaseStream.ReadAsync(block, token);
                            if (count == 0) break;
                            if (Running && session == Volatile.Read(ref generation))
                            {
                                provider.AddSamples(block, 0, count);
                                Volatile.Write(ref levelDb, AudioLevel.PeakDb(block, count, format));
                            }
                        }
                    }
                    catch (OperationCanceledException) { }
                    catch (Exception) { /* Device/network failure: UI can stop/retry preview. */ }
                }, token);
            }
            else
            {
                var provider = buffer;
                capture!.DataAvailable += (_, e) =>
                {
                    if (!Running || session != Volatile.Read(ref generation)) return;
                    provider.AddSamples(e.Buffer, 0, e.BytesRecorded);
                    Volatile.Write(ref levelDb, AudioLevel.PeakDb(e.Buffer, e.BytesRecorded, format));
                };
                capture.StartRecording();
            }
        }
        catch { Stop(); throw; }
    }

    public void Stop()
    {
        Running = false;
        Interlocked.Increment(ref generation);
        Volatile.Write(ref levelDb, -60);
        cancel?.Cancel();
        try { if (decoder is { HasExited: false }) decoder.Kill(entireProcessTree: true); } catch { }
        try { capture?.StopRecording(); } catch { }
        try { output?.Stop(); } catch { }
        decoder?.Dispose(); decoder = null;
        cancel?.Dispose(); cancel = null;
        capture?.Dispose(); capture = null;
        output?.Dispose(); output = null;
        buffer = null;
        inDevice?.Dispose(); inDevice = null;
        outDevice?.Dispose(); outDevice = null;
    }
    public void Dispose() => Stop();
}
