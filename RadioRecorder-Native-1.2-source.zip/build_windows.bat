@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>&1
if errorlevel 1 (
  echo .NET SDK 10 not found. Download: https://dotnet.microsoft.com/download/dotnet/10.0
  pause
  exit /b 1
)
echo === Compiling RadioRecorder C# WinForms Windows x64 ===
dotnet run --project tests\RadioRecorder.CoreTests.csproj --configuration Release
if errorlevel 1 (
  echo TESTS FAILED
  pause
  exit /b 1
)
dotnet publish RadioRecorder.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=false -p:PublishTrimmed=false -o publish\RadioRecorder
if errorlevel 1 (
  echo BUILD FAILED
  pause
  exit /b 1
)
if exist ffmpeg.exe copy /Y ffmpeg.exe publish\RadioRecorder\ffmpeg.exe
copy /Y QUICKSTART_RU.md publish\RadioRecorder\QUICKSTART_RU.md >nul
copy /Y README.md publish\RadioRecorder\README.md >nul
echo.
echo Ready: publish\RadioRecorder\RadioRecorder.exe (keep all DLL files)
if not exist publish\RadioRecorder\ffmpeg.exe echo IMPORTANT: add ffmpeg.exe next to the program.
pause
