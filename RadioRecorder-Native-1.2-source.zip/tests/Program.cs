using System.Text;
using NAudio.Wave;
using RadioRecorder.Core;

static void Test(bool ok, string name)
{
    if (!ok) throw new Exception("FAILED: " + name);
    Console.WriteLine("PASS " + name);
}
Test(AudioLevel.PeakDb(new byte[] { 0, 0, 255, 127 }, 4, new WaveFormat(48000, 16, 1)) > -1,
    "Audio meter detects input sound");
Test(AudioLevel.PeakDb(new byte[] { 0, 0, 0, 0 }, 4, new WaveFormat(48000, 16, 1)) == -60,
    "Audio meter silence");
DateTime t = new(2026, 10, 27, 12, 0, 0);
Test(Cue.Time(0) == "00:00:00", "CUE origin");
Test(Cue.Time(8.413333) == "00:08:31", "CUE CD frames");
var ev = new List<TrackEvent>
{
    new(t.AddSeconds(-100), "Трек A", "API"),
    new(t.AddSeconds(10), "ДЖИНГЛ", "API"),
    new(t.AddMinutes(2), "Трек Б", "API")
};
var cue = Cue.Generate("27-10-2026_12-00.mp3", t, t.AddHours(1), ev);
Test(cue.Contains("REM COMMENT  \"Created in RadioBOSS (Stream Archive)\""), "CUE header");
Test(cue.Contains("TITLE \"Трек A\"\r\n    INDEX 01 00:00:00"), "CUE carryover");
Test(cue.Contains("TITLE \"ДЖИНГЛ\"\r\n    INDEX 01 00:10:00"), "CUE jingles");
Test(cue.Contains("TRACK 03 AUDIO"), "CUE track numbering");
var next = Cue.Generate("27-10-2026_13-00.mp3", t.AddHours(1), t.AddHours(2), ev);
Test(next.Contains("TITLE \"Трек Б\"\r\n    INDEX 01 00:00:00"), "hour-boundary carryover");
var settings = new Settings { FilePattern = "%d-%m-%y_%hh-%mm" };
Test(RecorderService.Preview(settings, t) == "27-10-2026_12-00.mp3", "name template");
Test(Settings.NextClockHour(t.AddMinutes(23)) == t.AddHours(1), "manual Stop next hour");
Test(Settings.NextClockHour(new DateTime(2026, 10, 27, 23, 50, 0)) == new DateTime(2026, 10, 28, 0, 0, 0), "Stop across midnight");
settings.AutoSchedule = true;
Test(settings.ShouldAutoStart(t.AddMinutes(23), null), "Auto enabled starts on launch");
Test(!settings.ShouldAutoStart(t.AddMinutes(23), t.AddHours(1)), "Stop prevents restart this hour");
Test(settings.ShouldAutoStart(t.AddHours(1), t.AddHours(1)), "Auto resumes at next hour");
settings.Schedule[1][12] = false;
Test(!settings.ShouldAutoStart(t, null), "Auto obeys disabled hour");
Test(!settings.IsScheduled(t), "scheduler disabled Tuesday hour");
Test(settings.IsScheduled(t.AddHours(1)), "scheduler next hour");
string temp = Path.Combine(Path.GetTempPath(), "rr-native-cue-test-" + Guid.NewGuid() + ".cue");
try
{
    Cue.SaveAtomic(temp, cue);
    byte[] bytes = File.ReadAllBytes(temp);
    Test(bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF, "CUE UTF-8 BOM");
    Test(Encoding.UTF8.GetString(bytes).Contains("\r\n"), "CUE CRLF");
}
finally { if (File.Exists(temp)) File.Delete(temp); }

// Audio and CUE are intentionally independent: MP3 uses the selected Windows
// capture endpoint, while metadata comes from a separate HTTP API request.
var separate = new Settings { SourceKind = "device", Source = "wasapi:fake-test-id", MetadataMode = "api", ApiUrl = "http://localhost:9001" };
Test(separate.SourceKind == "device" && separate.MetadataMode == "api", "local line input and HTTP metadata coexist");
const string testApiXml = "<Root><TRACK STARTTIME=\"2026-10-27 12:00:10\" ARTIST=\"Артист\" TITLE=\"Название\" /></Root>";
var apiEvents = MetadataService.ParseLastPlayed(testApiXml);
Test(apiEvents.Count == 1 && apiEvents[0].Title == "Артист - Название", "RadioBOSS API extracts CUE metadata only");
string apiCue = Cue.Generate("27-10-2026_12-00.mp3", t, t.AddHours(1), apiEvents);
Test(apiCue.Contains("TITLE \"Артист - Название\""), "HTTP metadata becomes CUE title");

Console.WriteLine("ALL CORE TESTS PASSED");
