using System.Diagnostics;
using System.Security.Principal;
using Microsoft.Win32;

namespace RadioRecorder.Core;

/// <summary>
/// Registers the interactive user's login task with RunLevel=Highest.
/// Only task installation/removal is elevated (one UAC confirmation).
/// The task itself subsequently starts without UAC prompts at login.
/// No password is stored; it is bound to the user's interactive token.
/// </summary>
public static class WindowsAutostart
{
    private const string TaskName = "RadioRecorder";
    private const string LegacyRunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";

    public static void Configure(bool enabled)
    {
        if (!OperatingSystem.IsWindows()) return;
        bool currentlyExists = IsTaskRegistered();
        if (enabled && !currentlyExists)
            RunElevated("--install-autostart", GetCurrentUserSid());
        else if (!enabled && currentlyExists)
            RunElevated("--remove-autostart", GetCurrentUserSid());

        // The old Run-key startup would launch a second unelevated instance.
        using var key = Registry.CurrentUser.OpenSubKey(LegacyRunKey, writable: true);
        key?.DeleteValue(TaskName, throwOnMissingValue: false);
    }

    private static string GetCurrentUserSid() =>
        WindowsIdentity.GetCurrent().User?.Value ??
        throw new InvalidOperationException("Не удалось определить пользователя Windows");

    private static void RunElevated(string mode, string sid)
    {
        string executable = Environment.ProcessPath ??
            throw new InvalidOperationException("Нет пути к RadioRecorder.exe");
        using var process = Process.Start(new ProcessStartInfo
        {
            FileName = executable,
            Arguments = $"{mode} {sid}",
            Verb = "runas", // Windows UAC, only when the setting is first enabled/disabled
            UseShellExecute = true,
            WorkingDirectory = AppContext.BaseDirectory
        }) ?? throw new InvalidOperationException("Не удалось открыть настройку автозапуска");
        process.WaitForExit();
        if (process.ExitCode != 0)
            throw new InvalidOperationException("Не удалось настроить запуск от администратора. Подтверди запрос UAC и проверь права учётной записи.");
    }

    public static bool IsTaskRegistered()
    {
        try
        {
            dynamic scheduler = NewScheduler();
            dynamic root = scheduler.GetFolder(@"\");
            _ = root.GetTask(TaskName);
            return true;
        }
        catch { return false; }
    }

    private static dynamic NewScheduler()
    {
        Type comType = Type.GetTypeFromProgID("Schedule.Service") ??
            throw new InvalidOperationException("Планировщик заданий Windows недоступен");
        dynamic service = Activator.CreateInstance(comType)!;
        service.Connect();
        return service;
    }

    /// <summary>Called from the UAC-elevated child process only.</summary>
    public static int HandleElevatedCommand(string[] args)
    {
        if (args.Length != 2 || args[0] is not ("--install-autostart" or "--remove-autostart"))
            return 2;
        try
        {
            string targetSid = args[1];
            if (!System.Text.RegularExpressions.Regex.IsMatch(targetSid, @"^S-1-5-(?:\d+-)+\d+$"))
                return 2;
            dynamic scheduler = NewScheduler();
            dynamic root = scheduler.GetFolder(@"\");
            if (args[0] == "--remove-autostart")
            {
                try { root.DeleteTask(TaskName, 0); }
                catch (System.Runtime.InteropServices.COMException ex) when ((uint)ex.HResult == 0x80070002) { }
                return 0;
            }

            dynamic definition = scheduler.NewTask(0);
            definition.RegistrationInfo.Description = "RadioRecorder — автоматический запуск при входе в Windows";
            definition.Principal.UserId = targetSid;
            definition.Principal.LogonType = 3; // TASK_LOGON_INTERACTIVE_TOKEN
            definition.Principal.RunLevel = 1; // TASK_RUNLEVEL_HIGHEST
            definition.Settings.Enabled = true;
            definition.Settings.StartWhenAvailable = true;
            definition.Settings.ExecutionTimeLimit = "PT0S"; // 24/7 recording: no forced stop
            definition.Settings.AllowDemandStart = true;
            definition.Settings.DisallowStartIfOnBatteries = false;
            definition.Settings.StopIfGoingOnBatteries = false;
            definition.Settings.MultipleInstances = 2; // IgnoreNew
            dynamic trigger = definition.Triggers.Create(9); // TASK_TRIGGER_LOGON
            trigger.UserId = targetSid;
            dynamic action = definition.Actions.Create(0); // TASK_ACTION_EXEC
            action.Path = Environment.ProcessPath ?? throw new InvalidOperationException("Не найден RadioRecorder.exe");
            action.WorkingDirectory = AppContext.BaseDirectory;
            // TASK_CREATE_OR_UPDATE = 6, TASK_LOGON_INTERACTIVE_TOKEN = 3
            root.RegisterTaskDefinition(TaskName, definition, 6, null, null, 3, null);
            return 0;
        }
        catch (Exception ex)
        {
            try { File.WriteAllText(Path.Combine(Path.GetTempPath(), "RadioRecorder-autostart-error.txt"), ex.ToString()); }
            catch { }
            return 1;
        }
    }
}
