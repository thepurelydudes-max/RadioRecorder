# RadioRecorder Native 1.1

Portable C# / WinForms desktop audio recorder for Windows 10/11 x64. **Not a PyInstaller wrapper.**

**[Инструкция по-русски](QUICKSTART_RU.md)**

Features implemented in the source:
- Native WinForms main window, settings, schedule grid, archive browser, and embedded multi-size .ico icon (for executable and running windows).
- Windows WASAPI capture of the selected recording input, piping raw PCM to a separate native FFmpeg MP3 encoder; selectable bitrate, frequency, channels, output folder, filename pattern; optional HTTP audio source.
- Continuous FFmpeg segment muxing with local clock alignment (60 minutes → top of each hour).
- CUE per MP3 from independent RadioBOSS HTTP API (`playbackinfo`, `getlastplayed`) or ICY titles; CD 75-fps indices, UTF-8 BOM and CRLF, carrying over a track across segment boundaries.
- Separate Play monitoring with Windows WASAPI input/output selection and real PCM peak dBFS meter, independent of Rec/Stop.
- Schedule: Stop during Auto pauses until the next clock hour, Auto remains checked. Auto starts on program launch in a permitted schedule hour.
- Once-daily after-midnight retention deletes all expired regular files in a dedicated archive folder. Active MP3/CUE are excluded, symlinks and subdirectories not followed.
- Startup with Windows option, log, free-disk estimate, automatic FFmpeg restart on error.

## Build

A Windows machine with .NET 10 SDK can run `build_windows.bat`, or use `.github/workflows/windows-native.yml` in GitHub Actions. Both target self-contained multi-file `win-x64` using `dotnet publish` (`PublishSingleFile=false`).

The portable output folder contains `RadioRecorder.exe`, `RadioRecorder.dll`, managed DLLs (including NAudio), .NET runtime files, and an icon embedded in the EXE and displayed in all windows. FFmpeg is a **separate Windows-native third-party executable** distributed with its licenses. No `_internal` or Python. The complete folder must be kept together.

## Components

- `Core/Settings.cs`: configuration and schedule
- `Core/RecorderService.cs`: FFmpeg process, segment CUE timeline, retention
- `Core/MetadataService.cs`: XML RadioBOSS API / ICY metadata
- `Core/Cue.cs`: RadioBOSS CUE text output
- `Core/MonitorService.cs`: audio monitoring (NAudio 2.2.1)
- `UI/MainForm.cs`, `UI/SettingsForm.cs`, `UI/ScheduleForm.cs`: WinForms views
- `Assets/RadioRecorder.ico`: embedded Windows icon
- `tests`: minimal dependency-free C# core checks, run in CI

**Two independent data paths (default configuration):** The device selected in Windows WASAPI is the **only audio source for MP3**; RadioBOSS HTTP API `playbackinfo` / `getlastplayed` or ICY contributes **only title/time events to CUE**. HTTP/API errors do not stop device capture or MP3 encoding. Play previews the Windows input (not the metadata stream) and the meter shows captured audio amplitude.

**Status:** Native rewrite source ready for Windows CI build, **not locally compiled** (the authoring environment did not have dotnet or Windows). Windows compilation and real device operation must be verified before claiming a production-ready build. No SMTP silence notifications yet, no full equivalence with proprietary RadioLogger is claimed.

Copyright / licensing: Source code is provided as a starting project; NAudio is available on NuGet under MIT licensing. FFmpeg has its own license, which depends on the binaries/build configuration; see https://ffmpeg.org/legal.html.


### Автозагрузка с правами администратора (v1.2)

При выборе «Запускать вместе с Windows от администратора» программа **один раз** запросит подтверждение UAC, чтобы зарегистрировать интерактивное задание в Планировщике Windows. В последующие входы текущего пользователя программа стартует через Планировщик с параметром Highest RunLevel, без нового запроса UAC; при желании сворачивается и включает запись по галочке «Авто». Старый способ автозапуска через раздел `HKCU\...\Run` удаляется, чтобы избежать второго запуска. Для регистрации нужны права администратора; отключение также может запросить однократное подтверждение. Программа хранит пароль не в задаче, а лишь использует интерактивный токен текущего пользователя. Планировщик запускает программу **при входе в учётную запись**, не на экране входа. Если учётная запись не обладает правами администратора, отметка Highest сама по себе не даст ей прав администратора. Изменение ещё необходимо проверить на настоящей Windows.
