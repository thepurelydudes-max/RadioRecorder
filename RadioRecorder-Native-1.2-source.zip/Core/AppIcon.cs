using System.Drawing;
namespace RadioRecorder.Core;

public static class AppIcon
{
    public static Icon Load()
    {
        try
        {
            using var stream = typeof(AppIcon).Assembly.GetManifestResourceStream("RadioRecorder.Assets.RadioRecorder.ico");
            if (stream is not null)
            {
                using var icon = new Icon(stream);
                return (Icon)icon.Clone();
            }
        }
        catch { }
        try
        {
            var filename = Path.Combine(AppContext.BaseDirectory, "Assets", "RadioRecorder.ico");
            if (File.Exists(filename)) return new Icon(filename);
            if (Environment.ProcessPath is { } exe)
                return Icon.ExtractAssociatedIcon(exe) ?? (Icon)SystemIcons.Application.Clone();
        }
        catch { }
        return (Icon)SystemIcons.Application.Clone();
    }
}
